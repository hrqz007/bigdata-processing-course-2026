# -*- coding: utf-8 -*-
"""第12次课 | RDD最小补强：只讲懂基础概念，不重复四讲DataFrame。

运行位置：VS Code -> Remote SSH -> Ubuntu终端。
运行命令：/usr/local/spark/bin/spark-submit --master 'local[2]' 00_rdd_minilab.py
本课只使用内置4行字符串，不需要HDFS/YARN。
"""

from pyspark.sql import SparkSession  # SparkSession是你已学过的高层入口。

# 一、创建Spark会话。appName只是给本次程序起名字。
spark = SparkSession.builder.appName("L12_RDD_Minilab").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")  # 减少INFO日志，保留重要错误。

try:
    # 二、把Python的四行文本交给SparkContext，构造一个RDD。
    # SparkContext是更接近Spark底层计算的入口。
    # 第二个参数2明确指定两个RDD分区；local[2]表示两条本地计算线程。
    lines = ["pv buy", "pv cart", "buy pv", "fav pv"]
    rdd_lines = spark.sparkContext.parallelize(lines, 2)
    print("【原始数据】", lines)
    print("【RDD分区数】", rdd_lines.getNumPartitions())

    # 三、map：每条原始记录变成一张单词列表。
    # 结果是RDD[list]，仍然是一条记录对应一个输出列表。
    mapped = rdd_lines.map(lambda line: line.split())
    print("【map后前两条】", mapped.take(2))

    # 四、flatMap：先拆分每一条，再摊平为一个个词。
    # 输入4条文本，拆分后共有8个行为词。
    words = rdd_lines.flatMap(lambda line: line.split())
    print("【flatMap后的8个词】", words.take(8))

    # 五、filter：只保留允许的4种用户行为。
    # pv=Page View浏览；buy=购买；cart=加购物车；fav=收藏。
    allowed = {"pv", "buy", "cart", "fav"}
    clean_words = words.filter(lambda word: word in allowed)

    # 六、map：每个词转成(Key, Value)键值对，其中Value固定为1。
    # 例如："pv"变成("pv", 1)，表示一次浏览。
    pairs = clean_words.map(lambda word: (word, 1))

    # 七、reduceByKey：将相同Key的Value累加。
    # 和Hadoop MapReduce中的Shuffle思想相通，但这里是PySpark RDD API。
    result_rdd = pairs.reduceByKey(lambda a, b: a + b)

    # 八、collect属于Action，触发真正计算。
    # 注意：这里只收集4种小结果，不能对真实的大数据随便collect。
    counts = dict(result_rdd.collect())
    print("【RDD按行为统计】", sorted(counts.items()))

    # 九、教学数据可以用断言校验，错误时直接停止，不把错结果当成功。
    assert counts == {"pv": 4, "buy": 2, "cart": 1, "fav": 1}, counts
    print("RDD_BRIDGE_OK pv=4 buy=2 cart=1 fav=1")
finally:
    spark.stop()  # 释放本次Spark会话资源。
