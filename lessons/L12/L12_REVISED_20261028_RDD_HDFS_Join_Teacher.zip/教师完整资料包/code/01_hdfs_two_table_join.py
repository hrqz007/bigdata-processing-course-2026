# -*- coding: utf-8 -*-
"""第12次课 | HDFS两表Join、核对异常与结果输出（教学模拟数据）。

目标：在已经学过的DataFrame基础上，学习“订单表 + 商品表”的Join。
A：--orders orders_l12_A.csv --run runA
B：--orders orders_l12_B.csv --run runB

本程序支持 --source hdfs（本课主线）或 --source local（HDFS故障保底）。
local[2]指一台虚拟机中的两个本地工作线程，不等于两台集群机器。
"""

import argparse         # 读取 --orders、--run、--source 参数。
import getpass          # 获得当前Ubuntu用户名，避免全班写死hadoop。
import os               # 获取L12_HDFS_URI环境变量。
import re               # 检查run名称是否安全。
from pathlib import Path

from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType
)

# ===== 第1部分：程序启动参数（不要直接改程序路径） =====
parser = argparse.ArgumentParser(description="L12订单+商品双表Join")
parser.add_argument("--orders", required=True,
                    choices=["orders_l12_A.csv", "orders_l12_B.csv"],
                    help="需要读取哪一个订单文件")
parser.add_argument("--run", required=True,
                    help="此次输出编号，比如runA或runB；必须使用全新名称")
parser.add_argument("--source", choices=["hdfs", "local"], default="hdfs",
                    help="hdfs为课堂主线；local只用于HDFS故障时保底")
args = parser.parse_args()

# 目的：禁止把../等路径内容传给--run，以免输出跑到课程目录之外。
if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,30}", args.run):
    raise ValueError("--run只允许英文字母开头及字母/数字/下划线/短横线")

user = getpass.getuser()  # 如当前登录的是hadoop，得到字符串hadoop。
local_root = Path.home() / "bigdata_course" / "spark" / "lesson12_case"

if args.source == "hdfs":
    # L12_HDFS_URI由命令 `hdfs getconf -confKey fs.defaultFS` 自动取得。
    # 当前VM可能是hdfs://localhost:9000，也可能是其他端口，不写死。
    fs_uri = os.environ.get("L12_HDFS_URI", "").rstrip("/")
    if not fs_uri.startswith("hdfs://"):
        raise RuntimeError("未取得HDFS地址，请先执行：export L12_HDFS_URI=\"$(hdfs getconf -confKey fs.defaultFS)\"")
    root = f"{fs_uri}/user/{user}/bigdata/lesson12"
    orders_path = f"{root}/input/{args.orders}"
    products_path = f"{root}/input/products_l12.csv"
    output_root = f"{root}/output/{args.run}"
else:
    # 文件存在Ubuntu磁盘而非HDFS。仅在HDFS不可用时使用，不算完成HDFS目标。
    orders_path = (local_root / "data" / args.orders).resolve().as_uri()
    products_path = (local_root / "data" / "products_l12.csv").resolve().as_uri()
    output_root = (local_root / "output_local" / args.run).resolve().as_uri()

print("【输入来源】", args.source)
print("【订单文件】", orders_path)
print("【商品文件】", products_path)
print("【本次输出】", output_root)

# ===== 第2部分：创建会话与Schema =====
spark = SparkSession.builder.appName(f"L12_Join_{args.run}").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

try:
    # 我们主动定义字段类型，而不是让每个人机器猜测CSV数据类型。
    orders_schema = StructType([
        StructField("order_id", StringType(), True),     # 订单编号，例如o001
        StructField("user_id", StringType(), True),      # 用户编号，例如u01
        StructField("product_id", StringType(), True),   # 商品编号，Join连接键
        StructField("quantity", IntegerType(), True),   # 购买件数，例如2
        StructField("status", StringType(), True),      # paid=已支付，cancelled=取消
    ])
    products_schema = StructType([
        StructField("product_id", StringType(), True),      # 商品编号，Join连接键
        StructField("product_name", StringType(), True),    # 商品名
        StructField("category", StringType(), True),        # 类别：phone/book/... 
        StructField("unit_price_yuan", LongType(), True),   # 每件商品标价（元，教学整数）
    ])

    # header=true：CSV第一行是字段名，不当作一条订单。
    # schema：按照我们声明的字段类型解析，避免数量被误读成字符串。
    orders = spark.read.option("header", True).schema(orders_schema).csv(orders_path)
    products = spark.read.option("header", True).schema(products_schema).csv(products_path)

    print("【原始订单14条？】", orders.count())
    print("【商品表6条？】", products.count())

    # Join之前，先检查商品表product_id是否有重复：重复键会导致订单重复计算。
    if products.count() != products.select("product_id").distinct().count():
        raise ValueError("商品表product_id存在重复，停止计算：可能使金额重复")

    # 先只保留已支付记录（业务要求），取消订单不计入本课估算金额。
    paid = orders.filter(F.col("status") == F.lit("paid"))
    print("【已支付订单数】", paid.count())

    # ===== 第3部分：本课新知识Join =====
    # left：保留左表所有已支付订单，即使没有匹配到商品仍然保留。
    # on="product_id"：左表和右表用相同商品编号连接。
    joined = paid.join(products, on="product_id", how="left")
    print("【Left Join后的订单数】", joined.count())

    # 没匹配到产品：右表product_name等列是NULL，不能直接用它计算金额。
    unmatched = joined.filter(F.col("product_name").isNull())
    matched = joined.filter(F.col("product_name").isNotNull())
    print("【匹配到商品的订单数】", matched.count())
    print("【未匹配的订单数】", unmatched.count())
    print("【未匹配记录】")
    unmatched.select("order_id", "product_id", "quantity").show(truncate=False)

    # ===== 第4部分：用已学过的DataFrame API做分组统计 =====
    # unit_price_yuan是商品“当前标价”，非实际成交单价。
    # estimated_amount_yuan仅表示：匹配成功订单按标价推算的金额。
    # 不能把这个教学估算金额直接宣传为真实营业额。
    summary = (
        matched
        .withColumn("estimated_line_yuan",
                    F.col("quantity") * F.col("unit_price_yuan"))
        .groupBy("category")
        .agg(
            F.count("*").alias("matched_order_lines"),
            F.sum("estimated_line_yuan").alias("estimated_amount_yuan"),
        )
        .orderBy("category")
    )
    print("【类别汇总：已匹配订单按当前标价估算】")
    summary.show(100, truncate=False)

    # 只收集6行统计结果用于本教学小数据自检；真实大表不得随便collect。
    amount_rows = summary.select("category", "estimated_amount_yuan").collect()
    amount_map = {r["category"]: int(r["estimated_amount_yuan"]) for r in amount_rows}
    total_estimated = sum(amount_map.values())
    print("【各类别估算金额】", sorted(amount_map.items()))
    print("【已匹配估算金额合计】", total_estimated)

    # ===== 第5部分：将结果保存为目录 =====
    # errorifexists：如果该目录已经存在，就停下报错；不覆盖以前的runA。
    # CSV写出的是目录，而不保证只生成一个.csv文件。
    summary.write.mode("errorifexists").option("header", True).csv(
        f"{output_root}/category_summary"
    )
    unmatched.select("order_id", "product_id", "quantity").write \
        .mode("errorifexists").option("header", True).csv(
            f"{output_root}/unmatched_orders"
        )

    print("L12_JOIN_OK", args.run, "paid_matched_amount_yuan", total_estimated)
    print("提示：该数值是匹配到商品订单按标价估算的金额，不含无法匹配的p999。")
finally:
    # 即使出错，也应该释放Spark会话；虚拟机下次仍可重新启动Spark。
    spark.stop()
