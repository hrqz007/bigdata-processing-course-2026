第12次课修订版｜RDD补强 + HDFS双表Join

重要前提：学生已经用两次课完成PySpark四讲（DataFrame/API、筛选、聚合、保存）；本课不会重复整节DataFrame入门，也不会再做旧版RDD WordCount。

建议按下列顺序准备：
1. 00_课堂执行总览.docx：100分钟时间表与A/B/C边界
2. 02_教师零基础完整教程.docx：原理与业务含义
3. 10_命令与源码逐条解读手册.docx：每条命令的目的/参数/预期
4. 01_PPT...pptx + 06_教师PPT逐页讲解提示.docx
5. 09_教师课前预检与故障预案.docx：在自己的Ubuntu母盘完整跑runA与runB
6. 05_教师参考_答案与验收.docx：独立人工答案

【源代码与数据在哪里？】
code/00_rdd_minilab.py
code/01_hdfs_two_table_join.py
data/orders_l12_A.csv
data/products_l12.csv

【教师Python独立核算】
在当前教师资料包根目录执行：python3 09_教师参考/teacher_independent_check.py
这不需要Spark，结果用于验证小样本。

【学生包区别】
不包含教师答案、教师参考B文件和评分表。学生只拿code/、data/、07_分步复制命令及教程。

【验证边界】
所有Python文件做语法检查，所有CSV做独立数值核算，DOCX/PPT已渲染检查；尚未在Holmes自己的Ubuntu上实际运行Spark/HDFS联动，授课前必须教师机验证。

【不建议课堂做】
不安装新Spark；不重装Hadoop；不随意修改.bashrc；不执行hdfs namenode -format；不让学生一键黑箱.sh。