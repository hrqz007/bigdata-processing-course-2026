# -*- coding: utf-8 -*-
"""教师独立数据核算脚本：不用Spark、不改HDFS，只读取本地CSV。
用途：独立验证授课例子的业务答案，不能代替学生的Spark程序验收。
"""
from pathlib import Path
from collections import defaultdict
import csv
ROOT = Path(__file__).resolve().parents[1]
products = {r['product_id']: r for r in csv.DictReader((ROOT/'data/products_l12.csv').open(encoding='utf-8'))}
base = list(csv.DictReader((ROOT/'data/orders_l12_A.csv').open(encoding='utf-8')))
for label, rows in [('runA', base), ('runB', [{**r, 'status': ('paid' if r['order_id']=='o005' else r['status'])} for r in base])]:
    paid = [r for r in rows if r['status']=='paid']
    sums = defaultdict(int)
    unmatched = []
    for r in paid:
        p = products.get(r['product_id'])
        if p is None:
            unmatched.append(r['order_id'])
        else:
            sums[p['category']] += int(r['quantity']) * int(p['unit_price_yuan'])
    print(label, 'paid=',len(paid),'matched=',len(paid)-len(unmatched),'unmatched=',unmatched,'by_category=',dict(sorted(sums.items())),'total=',sum(sums.values()))
