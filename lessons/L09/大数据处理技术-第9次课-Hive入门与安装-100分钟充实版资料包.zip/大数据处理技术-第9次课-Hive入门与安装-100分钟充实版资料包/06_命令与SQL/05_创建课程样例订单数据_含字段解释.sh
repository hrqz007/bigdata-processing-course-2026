#!/usr/bin/env bash
# ================================================================
# 第9次课：创建订单样例CSV
#
# 字段说明：
# order_id   = Order ID，订单编号
# user_id    = User ID，用户编号
# item_id    = Item ID，商品编号
# category   = 商品类别
# amount     = 订单金额
# status     = 订单状态
#              paid      已支付
#              cancelled 已取消
# event_time = 订单事件发生时间
# ================================================================

set -euo pipefail

WORK="$HOME/bigdata_course/hive/lesson9"
mkdir -p "$WORK"

cat > "$WORK/orders_lesson9.csv" <<'EOF'
order_id,user_id,item_id,category,amount,status,event_time
o001,u001,i101,phone,3999.00,paid,2026-09-28 09:01:00
o002,u002,i102,computer,5999.00,paid,2026-09-28 09:03:00
o003,u003,i103,book,89.00,paid,2026-09-28 09:05:00
o004,u001,i104,accessory,199.00,paid,2026-09-28 09:08:00
o005,u004,i105,phone,2999.00,cancelled,2026-09-28 09:11:00
o006,u005,i106,book,129.00,paid,2026-09-28 09:15:00
o007,u006,i107,computer,4599.00,paid,2026-09-28 09:18:00
o008,u002,i108,accessory,299.00,paid,2026-09-28 09:22:00
o009,u007,i109,phone,1999.00,paid,2026-09-28 09:25:00
o010,u008,i110,book,59.00,cancelled,2026-09-28 09:28:00
o011,u003,i111,accessory,399.00,paid,2026-09-28 09:31:00
o012,u009,i112,phone,4999.00,paid,2026-09-28 09:35:00
EOF

echo "===== 文件位置 ====="
echo "$WORK/orders_lesson9.csv"

echo
echo "===== 前5行 ====="
head -n 5 "$WORK/orders_lesson9.csv"

echo
echo "===== 总行数 ====="
# 13行 = 1行表头 + 12条订单记录。
wc -l "$WORK/orders_lesson9.csv"
