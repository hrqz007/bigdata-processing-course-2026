#!/usr/bin/env bash
# =====================================================================
# 第9次课：配置Hive本地Metastore + HDFS Warehouse
#
# Metastore（元数据仓库）保存：
# 数据库名、表名、列名、数据类型、HDFS位置等“描述数据的数据”。
# 它不是保存订单CSV真正内容的地方。
#
# 本课程每名学生都有独立虚拟机，所以使用Hive自带的嵌入式Derby：
# 优点：简单、无需再配置MySQL账号和JDBC驱动。
# 限制：同一Metastore不适合多个Hive进程并发访问。
# =====================================================================

set -euo pipefail

if [ ! -d /usr/local/hive ]; then
  echo "ERROR: /usr/local/hive不存在。请先安装Hive。"
  exit 1
fi

echo "===== 1. 检查HDFS和YARN是否已经启动 ====="
jps

if ! jps | grep -q NameNode; then
  echo "ERROR: NameNode未运行。请先执行01_每次上课_启动HDFS和YARN并健康检查.sh"
  exit 1
fi

echo
echo "===== 2. 创建本地Metastore目录 ====="

# 真实元数据数据库文件会放在这里。
mkdir -p "$HOME/hive_metastore"

# Hive本地临时目录。
mkdir -p "$HOME/hive_tmp"

echo
echo "===== 3. 备份已有hive-site.xml（如果存在） ====="

if [ -f /usr/local/hive/conf/hive-site.xml ]; then
  cp /usr/local/hive/conf/hive-site.xml \
     "/usr/local/hive/conf/hive-site.xml.bak.$(date +%Y%m%d_%H%M%S)"
  echo "原配置已备份。"
fi

echo
echo "===== 4. 写入本课程Hive配置 ====="

cat > /usr/local/hive/conf/hive-site.xml <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

  <!--
    Metastore连接地址。
    Derby数据库文件固定放到/home/hadoop/hive_metastore/metastore_db，
    避免因为当前目录不同而生成多个metastore_db。
  -->
  <property>
    <name>javax.jdo.option.ConnectionURL</name>
    <value>jdbc:derby:${HOME}/hive_metastore/metastore_db;create=true</value>
  </property>

  <!-- Derby嵌入式驱动 -->
  <property>
    <name>javax.jdo.option.ConnectionDriverName</name>
    <value>org.apache.derby.jdbc.EmbeddedDriver</value>
  </property>

  <!-- Derby默认用户，本课程无需单独设置数据库密码 -->
  <property>
    <name>javax.jdo.option.ConnectionUserName</name>
    <value>APP</value>
  </property>

  <!-- Hive默认数据仓库目录：真实表数据主要在HDFS -->
  <property>
    <name>hive.metastore.warehouse.dir</name>
    <value>/user/hive/warehouse</value>
  </property>

  <!-- Hive在HDFS中的临时目录 -->
  <property>
    <name>hive.exec.scratchdir</name>
    <value>/tmp/hive</value>
  </property>

  <!--
    本课程先使用MapReduce执行引擎，
    这样可以直接联系前面学过的MapReduce与YARN。
  -->
  <property>
    <name>hive.execution.engine</name>
    <value>mr</value>
  </property>

  <!-- 查询输出显示列名，便于初学者读结果 -->
  <property>
    <name>hive.cli.print.header</name>
    <value>true</value>
  </property>

  <!-- 结果列名不过度追加tablename前缀，课堂输出更易读 -->
  <property>
    <name>hive.resultset.use.unique.column.names</name>
    <value>false</value>
  </property>

</configuration>
EOF

echo
echo "===== 5. 准备HDFS中的Hive目录 ====="

# /tmp：Hive执行任务时会使用的公共临时区域。
hdfs dfs -mkdir -p /tmp

# /user/hive/warehouse：Hive默认warehouse。
hdfs dfs -mkdir -p /user/hive/warehouse

# 官方入门文档建议让组用户具备写权限。
hdfs dfs -chmod g+w /tmp
hdfs dfs -chmod g+w /user/hive/warehouse

# Hive 0.14+通常会使用/tmp/hive作为HDFS临时目录。
hdfs dfs -mkdir -p /tmp/hive
hdfs dfs -chmod 777 /tmp/hive

echo
echo "===== 6. 初始化Derby Metastore Schema ====="

# 先尝试读取schema信息。
# 如果能成功，说明以前已经初始化，不再重复init。
if schematool -dbType derby -info >/tmp/hive_schema_info.txt 2>&1; then
  echo "Metastore已经初始化："
  cat /tmp/hive_schema_info.txt
else
  echo "第一次使用Hive，开始初始化Metastore Schema..."
  schematool -dbType derby -initSchema
fi

echo
echo "===== 7. 最终验证Schema ====="
schematool -dbType derby -info

echo
echo "Hive Metastore与Warehouse准备完成。"
