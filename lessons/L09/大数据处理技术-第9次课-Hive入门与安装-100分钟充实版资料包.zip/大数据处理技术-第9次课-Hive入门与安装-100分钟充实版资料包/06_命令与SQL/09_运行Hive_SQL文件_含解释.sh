#!/usr/bin/env bash
# ================================================================
# 第9次课：使用Beeline批量运行Hive SQL文件
#
# 本课程使用：
# beeline -u jdbc:hive2://
#
# 这是教学用的“嵌入式/本地测试”连接方式，
# 不需要本课额外启动一个对外监听的HiveServer2。
# ================================================================

set -euo pipefail

SQL_DIR="$HOME/bigdata_course/hive/lesson9/sql"

echo "===== 1. 检查SQL目录 ====="
ls -lh "$SQL_DIR"

echo
echo "===== 2. 创建数据库与外部表 ====="
# -u：JDBC连接URL。
# -n：Hive会话用户名。
# -f：执行指定SQL文件。
beeline -u 'jdbc:hive2://' -n "$USER" \
  -f "$SQL_DIR/07_Hive_SQL_创建数据库与外部表.sql"

echo
echo "===== 3. 执行基础查询与聚合 ====="
beeline -u 'jdbc:hive2://' -n "$USER" \
  -f "$SQL_DIR/08_Hive_SQL_基础查询与聚合.sql"
