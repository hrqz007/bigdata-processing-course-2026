#!/usr/bin/env bash
# ================================================================
# 第9次课：证明“表定义”和“真实数据文件”是两件事
# ================================================================

echo "===== 1. 查看订单HDFS目录 ====="
hdfs dfs -ls -h "/user/$USER/bigdata/lesson9/orders"

echo
echo "===== 2. 直接读取HDFS中的原始CSV ====="
hdfs dfs -cat "/user/$USER/bigdata/lesson9/orders/orders_lesson9.csv" | head -n 5

echo
echo "===== 3. 查看Hive默认warehouse ====="
# 外部表本课使用自定义LOCATION，所以orders_ext数据不一定出现在warehouse下。
hdfs dfs -ls -h /user/hive/warehouse || true

echo
echo "课堂结论："
echo "orders_ext的表结构由Hive Metastore记录；真正CSV仍在指定HDFS LOCATION中。"
