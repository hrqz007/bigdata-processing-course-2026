#!/usr/bin/env bash
# ================================================================
# 第9次课：把本地CSV上传到HDFS
#
# 目的：
# 让“真实数据”继续保存在HDFS中。
# Hive稍后只给这些文件附加“表结构”，而不是把数据搬进MySQL。
# ================================================================

set -euo pipefail

LOCAL_FILE="$HOME/bigdata_course/hive/lesson9/orders_lesson9.csv"
HDFS_DIR="/user/$USER/bigdata/lesson9/orders"

echo "===== 1. 创建HDFS目录 ====="
# -p：父目录不存在时一起创建；已存在也不会报错。
hdfs dfs -mkdir -p "$HDFS_DIR"

echo
echo "===== 2. 上传CSV ====="
# -put：本地Linux文件 → HDFS。
# -f：如果同名文件已经存在，则覆盖，便于课堂重复练习。
hdfs dfs -put -f "$LOCAL_FILE" "$HDFS_DIR/"

echo
echo "===== 3. 查看HDFS目录 ====="
hdfs dfs -ls -h "$HDFS_DIR"

echo
echo "===== 4. 直接读取HDFS文件前5行 ====="
# 这里证明：数据此刻已经在HDFS，不需要Hive也能看到。
hdfs dfs -cat "$HDFS_DIR/orders_lesson9.csv" | head -n 5
