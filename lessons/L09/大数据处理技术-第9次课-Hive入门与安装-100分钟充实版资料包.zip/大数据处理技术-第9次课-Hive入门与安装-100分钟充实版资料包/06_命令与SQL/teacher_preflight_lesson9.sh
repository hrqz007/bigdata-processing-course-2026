#!/usr/bin/env bash
# 教师课前只读/低风险预检
# 不自动安装、不删除Hive、不格式化HDFS。

set -u

echo "===== OS ====="
cat /etc/os-release | grep -E 'PRETTY_NAME|VERSION_ID'

echo
echo "===== Java ====="
java -version
javac -version

echo
echo "===== Hadoop ====="
hadoop version | head -n 1
echo "HADOOP_HOME=${HADOOP_HOME:-<empty>}"

echo
echo "===== Maven ====="
mvn -version | head -n 4 || true

echo
echo "===== Hive ====="
command -v beeline || true
command -v schematool || true
if [ -x /usr/local/hive/bin/hive ]; then
  /usr/local/hive/bin/hive --version 2>&1 | head -n 6
else
  echo "Hive尚未安装。"
fi

echo
echo "===== 当前Java进程 ====="
jps

echo
echo "===== HDFS地址 ====="
hdfs getconf -confKey fs.defaultFS

echo
echo "===== YARN节点（如果YARN已启动） ====="
yarn node -list 2>&1 | head -n 20 || true

echo
echo "预检完成。"
