#!/usr/bin/env bash
# ================================================================
# 第9次课：下课前正确停止服务
# ================================================================

echo "===== 1. 停止YARN ====="
# 停止ResourceManager和NodeManager。
stop-yarn.sh

echo
echo "===== 2. 停止HDFS ====="
# 停止NameNode、DataNode、SecondaryNameNode。
stop-dfs.sh

echo
echo "===== 3. 验证 ====="
# Hadoop/YARN核心进程应消失。
jps

echo
echo "收尾完成。现在可以保存VS Code文件并关闭虚拟机。"
