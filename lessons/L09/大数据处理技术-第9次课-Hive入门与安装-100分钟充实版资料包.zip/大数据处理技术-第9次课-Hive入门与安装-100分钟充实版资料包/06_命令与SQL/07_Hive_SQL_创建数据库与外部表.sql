-- ================================================================
-- 第9次课：Hive第一张表
--
-- 本文件重点：
-- 数据已经在HDFS；
-- Hive只保存“这7列分别叫什么、是什么类型、文件在哪里”等元数据。
-- 这就是Schema on Read（读时模式）的一种直观体现。
-- ================================================================

-- 创建课程数据库。
-- IF NOT EXISTS：已经存在时不报错，方便重复练习。
CREATE DATABASE IF NOT EXISTS bigdata_course;

-- 切换到课程数据库。
USE bigdata_course;

-- 为了让本SQL可以重复运行，先删除旧的“表定义”。
-- 因为这是EXTERNAL外部表，DROP TABLE通常不会删除LOCATION中的原始HDFS文件。
DROP TABLE IF EXISTS orders_ext;

-- 创建外部表。
CREATE EXTERNAL TABLE orders_ext (

  -- 订单编号，例如o001。
  order_id STRING,

  -- 用户编号，例如u001。
  user_id STRING,

  -- 商品编号，例如i101。
  item_id STRING,

  -- 商品类别：phone / computer / book / accessory。
  category STRING,

  -- 订单金额，DOUBLE表示带小数的数值。
  amount DOUBLE,

  -- 订单状态：paid=已支付，cancelled=已取消。
  status STRING,

  -- 为降低本课难度，时间先按STRING保存。
  event_time STRING
)

-- 告诉Hive：一行中的字段用英文逗号分隔。
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','

-- 原始数据是普通文本文件。
STORED AS TEXTFILE

-- 关键：这张表指向已经存在的HDFS目录。
LOCATION '/user/hadoop/bigdata/lesson9/orders'

-- CSV第一行是字段名表头，不当作业务数据读取。
TBLPROPERTIES ('skip.header.line.count'='1');

-- 查看当前数据库中的表。
SHOW TABLES;

-- 查看表结构。
DESCRIBE orders_ext;

-- 先看前5条记录，验证字段是否正确解析。
SELECT *
FROM orders_ext
LIMIT 5;
