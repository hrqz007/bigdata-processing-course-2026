#!/usr/bin/env bash
# =====================================================================
# 第9次课：Apache Hive 3.1.3 首次安装脚本
#
# 适用课程环境：
# Ubuntu 22.04
# JDK 1.8
# Hadoop 3.3.5（/usr/local/hadoop）
#
# 为什么选Hive 3.1.3？
# Apache官方发布说明明确该版本可配合Hadoop 3.x.y。
# 课程现有环境冻结在JDK 8 + Hadoop 3.3.5，因此选择这个兼容性较低风险的版本。
#
# 重要：
# Hive 3.x已经停止官方维护，本脚本只用于隔离的教学虚拟机，
# 不代表新生产系统的版本建议。
#
# 脚本尽量不修改 ~/.bashrc，避免再次造成PATH污染。
# =====================================================================

set -euo pipefail

HIVE_VERSION="3.1.3"
ARCHIVE="apache-hive-${HIVE_VERSION}-bin.tar.gz"
INSTALL_DIR="/usr/local/apache-hive-${HIVE_VERSION}-bin"
HIVE_LINK="/usr/local/hive"
DOWNLOAD_URL="https://archive.apache.org/dist/hive/hive-${HIVE_VERSION}/${ARCHIVE}"

echo "===== A. 安装前检查 ====="

# 检查Java。Hive需要Java环境。
java -version

# 检查javac，确认是完整JDK而不仅是JRE。
javac -version

# 检查Hadoop版本。
hadoop version | head -n 1

# 确认Hadoop固定安装目录存在。
if [ ! -d /usr/local/hadoop ]; then
  echo "ERROR: /usr/local/hadoop 不存在。停止安装，请找教师检查。"
  exit 1
fi

# 如果Hive已经存在，则不重复覆盖安装。
if [ -x "${HIVE_LINK}/bin/hive" ]; then
  echo "检测到${HIVE_LINK}/bin/hive，Hive似乎已经安装。"
  echo "为了避免覆盖已有环境，本脚本到此停止。"
  echo "请运行：/usr/local/hive/bin/hive --version"
  exit 0
fi

echo
echo "===== B. 查找Hive安装包 ====="
# 推荐课堂上由教师提前把312MB左右的Hive压缩包发给学生。
# 脚本会优先在常见目录寻找，避免全班同时上网下载。

SOURCE=""

for candidate in \
  "$HOME/Downloads/$ARCHIVE" \
  "$HOME/Desktop/$ARCHIVE" \
  "$HOME/$ARCHIVE" \
  "/tmp/$ARCHIVE"
do
  if [ -f "$candidate" ]; then
    SOURCE="$candidate"
    break
  fi
done

if [ -n "$SOURCE" ]; then
  echo "找到本地安装包：$SOURCE"
else
  echo "没有找到本地安装包，将尝试从Apache历史归档下载。"
  echo "如果机房网络较慢，建议Ctrl+C停止，然后使用教师提供的本地压缩包。"

  # 检查wget。
  if ! command -v wget >/dev/null 2>&1; then
    echo "系统没有wget，先安装wget。"
    sudo apt update
    sudo apt install -y wget
  fi

  SOURCE="/tmp/$ARCHIVE"
  wget -O "$SOURCE" "$DOWNLOAD_URL"
fi

echo
echo "===== C. 解压Hive到/usr/local ====="

# 把压缩包解压到/usr/local。
sudo tar -xzf "$SOURCE" -C /usr/local

# 建立固定路径/usr/local/hive。
# 以后课程材料无需记住完整版本目录名。
sudo ln -sfn "$INSTALL_DIR" "$HIVE_LINK"

# 让课程用户拥有Hive目录，方便查看和备份配置文件。
sudo chown -R "$(whoami)":"$(id -gn)" "$INSTALL_DIR"

echo
echo "===== D. 配置hive-env.sh ====="

# 自动识别JDK根目录。
JAVAC_REAL="$(readlink -f "$(command -v javac)")"
JAVA_HOME_DETECTED="$(dirname "$(dirname "$JAVAC_REAL")")"

cat > "${HIVE_LINK}/conf/hive-env.sh" <<EOF
# 本课程统一Hive环境
# Hadoop安装目录
export HADOOP_HOME=/usr/local/hadoop

# 自动检测出的JDK目录
export JAVA_HOME=${JAVA_HOME_DETECTED}

# Hive配置目录
export HIVE_CONF_DIR=/usr/local/hive/conf
EOF

echo "检测到JAVA_HOME=${JAVA_HOME_DETECTED}"

echo
echo "===== E. 处理Hive 3.1.3与Hadoop 3.3.x常见Guava版本冲突 ====="

# Hive 3.1.3自带的Guava较旧，而Hadoop 3.3.x通常自带较新的Guava。
# 如果同时加载不兼容版本，Hive可能出现NoSuchMethodError。
# 教学环境统一让Hive使用Hadoop当前的Guava版本。

HADOOP_GUAVA="$(find /usr/local/hadoop/share/hadoop/common/lib -maxdepth 1 -name 'guava-*.jar' | head -n 1 || true)"
HIVE_GUAVA="$(find "${HIVE_LINK}/lib" -maxdepth 1 -name 'guava-*.jar' | head -n 1 || true)"

echo "Hadoop Guava: ${HADOOP_GUAVA:-未找到}"
echo "Hive原Guava: ${HIVE_GUAVA:-未找到}"

if [ -n "$HADOOP_GUAVA" ]; then
  mkdir -p "${HIVE_LINK}/lib_backup"

  # 先备份Hive自带Guava，不直接永久删除。
  if [ -n "$HIVE_GUAVA" ] && [ -f "$HIVE_GUAVA" ]; then
    cp -n "$HIVE_GUAVA" "${HIVE_LINK}/lib_backup/" || true
  fi

  # 删除Hive lib中的旧Guava并复制Hadoop正在使用的Guava。
  find "${HIVE_LINK}/lib" -maxdepth 1 -name 'guava-*.jar' -delete
  cp "$HADOOP_GUAVA" "${HIVE_LINK}/lib/"
fi

echo
echo "===== F. 创建不依赖.bashrc的命令包装器 ====="

# 为什么做包装器？
# VS Code Remote SSH的新终端不一定读取我们预期的profile文件。
# 把包装器放进/usr/local/bin后，hive/beeline/schematool可直接使用，
# 又不用反复修改学生的~/.bashrc。

for cmd in hive beeline schematool hiveserver2; do
  sudo tee "/usr/local/bin/${cmd}" >/dev/null <<EOF
#!/usr/bin/env bash
export HIVE_HOME=/usr/local/hive
export HADOOP_HOME=/usr/local/hadoop
export HIVE_CONF_DIR=/usr/local/hive/conf
exec /usr/local/hive/bin/${cmd} "\$@"
EOF
  sudo chmod +x "/usr/local/bin/${cmd}"
done

hash -r

echo
echo "===== G. 安装结果检查 ====="
echo "beeline位置: $(command -v beeline)"
echo "schematool位置: $(command -v schematool)"
echo
/usr/local/hive/bin/hive --version 2>&1 | head -n 8

echo
echo "Hive 3.1.3软件文件安装完成。"
echo "下一步请运行：04_准备Hive仓库和Metastore_首次或修复用.sh"
