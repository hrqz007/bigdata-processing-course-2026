#!/usr/bin/env bash
# ================================================================
# 第9次课：检查Hive是否已经安装
# 这个脚本只检查，不修改系统。
# ================================================================

echo "===== 1. 检查Hive命令 ====="
# command -v：让Linux告诉我们命令位于哪里。
if command -v beeline >/dev/null 2>&1; then
  echo "找到beeline: $(command -v beeline)"
else
  echo "未找到beeline。说明Hive可能尚未安装，或命令未配置。"
fi

if command -v schematool >/dev/null 2>&1; then
  echo "找到schematool: $(command -v schematool)"
else
  echo "未找到schematool。"
fi

echo
echo "===== 2. 检查Hive安装目录 ====="
if [ -d /usr/local/hive ]; then
  ls -ld /usr/local/hive
else
  echo "/usr/local/hive 不存在。"
fi

echo
echo "===== 3. 如果已经安装，查看版本 ====="
if [ -x /usr/local/hive/bin/hive ]; then
  /usr/local/hive/bin/hive --version 2>&1 | head -n 5
else
  echo "Hive尚未安装，等待执行首次安装脚本。"
fi
