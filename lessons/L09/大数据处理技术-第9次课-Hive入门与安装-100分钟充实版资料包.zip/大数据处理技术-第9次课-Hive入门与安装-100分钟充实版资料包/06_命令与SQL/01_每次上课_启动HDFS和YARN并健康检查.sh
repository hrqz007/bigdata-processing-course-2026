#!/usr/bin/env bash
# ================================================================
# 第9次课：每次开机后的固定启动流程
# 适用：Ubuntu 22.04 + Hadoop 3.3.5
#
# 为什么要先做这一步？
# 虚拟机每次重新开机后，HDFS和YARN默认并不会自动启动。
# Hive需要读取HDFS中的数据；复杂Hive SQL还可能提交MapReduce到YARN。
# 所以必须先启动并检查它们。
# ================================================================

set -u

echo "===== 1. 当前远程主机确认 ====="
# 目的：确认你现在确实在Ubuntu虚拟机中，而不是Windows本地终端。
echo "当前用户: $(whoami)"
echo "当前主机: $(hostname)"
echo "当前目录: $(pwd)"
echo

echo "===== 2. Hadoop版本 ====="
# 目的：确认Hadoop命令可用。
hadoop version | head -n 1
echo

echo "===== 3. 启动HDFS ====="
# 目的：启动NameNode、DataNode、SecondaryNameNode。
# 如果已经启动，脚本可能提示进程已存在，这不是严重错误。
start-dfs.sh
echo

echo "===== 4. 启动YARN ====="
# 目的：启动ResourceManager和NodeManager。
start-yarn.sh
echo

echo "===== 5. 查看Java进程 ====="
# 正常情况下，本课希望看到：
# NameNode
# DataNode
# SecondaryNameNode
# ResourceManager
# NodeManager
# Jps
jps
echo

echo "===== 6. 检查HDFS Safe Mode ====="
# 目的：确认HDFS当前是否允许正常写入。
hdfs dfsadmin -safemode get
echo

echo "===== 7. 检查DataNode ====="
# 目的：确认DataNode已经向NameNode注册。
hdfs dfsadmin -report | grep -E "Live datanodes|Hostname|Decommission Status" || true
echo

echo "===== 8. 检查YARN节点 ====="
# 目的：确认NodeManager已经加入ResourceManager。
yarn node -list
echo

echo "===== 验收标准 ====="
echo "如果jps中有HDFS三个进程 + YARN两个进程，且yarn node -list显示1个RUNNING节点，即可继续。"
