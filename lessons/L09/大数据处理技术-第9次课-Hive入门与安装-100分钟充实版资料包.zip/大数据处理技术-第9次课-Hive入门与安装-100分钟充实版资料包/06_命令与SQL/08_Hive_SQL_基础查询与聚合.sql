-- ================================================================
-- 第9次课：Hive SQL基础查询
-- 目标：用少量SQL替代前面大量Java Mapper/Reducer样板代码。
-- ================================================================

USE bigdata_course;

-- 任务1：查看全部订单数。
SELECT COUNT(*) AS total_orders
FROM orders_ext;

-- 任务2：只看已支付订单。
-- WHERE用于“按条件过滤记录”。
SELECT order_id, user_id, category, amount
FROM orders_ext
WHERE status = 'paid'
LIMIT 10;

-- 任务3：按订单状态统计数量。
--
-- GROUP BY status：
-- 把相同status的行归到同一组。
--
-- COUNT(*)：
-- 统计每组有多少行。
--
-- 这和前面MapReduce的思想非常接近：
-- Mapper输出(status,1) → Shuffle按status分组 → Reducer求和。
SELECT
  status,
  COUNT(*) AS order_count
FROM orders_ext
GROUP BY status
ORDER BY order_count DESC;

-- 任务4：统计“已支付”订单中，各商品类别的成交金额。
SELECT
  category,
  ROUND(SUM(amount), 2) AS paid_amount
FROM orders_ext
WHERE status = 'paid'
GROUP BY category
ORDER BY paid_amount DESC;

-- 任务5：UV（Unique Visitor，去重用户数）。
-- COUNT(DISTINCT user_id)表示：同一个用户多次购买只算1个用户。
SELECT
  COUNT(DISTINCT user_id) AS paid_uv
FROM orders_ext
WHERE status = 'paid';

-- 任务6：EXPLAIN不是执行查询，而是让Hive展示“准备怎么执行”。
-- 用它帮助观察SQL背后仍然存在执行计划。
EXPLAIN
SELECT
  status,
  COUNT(*) AS order_count
FROM orders_ext
GROUP BY status;
