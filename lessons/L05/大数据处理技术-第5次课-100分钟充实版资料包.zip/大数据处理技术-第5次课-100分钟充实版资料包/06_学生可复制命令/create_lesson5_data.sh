#!/usr/bin/env bash
set -euo pipefail
LOCAL5="$HOME/bigdata_course/lesson5"
mkdir -p "$LOCAL5"
cat > "$LOCAL5/orders.csv" <<'EOF'
order_id,user_id,product,category,amount,status
o1001,u001,keyboard,digital,199,paid
o1002,u002,mouse,digital,89,paid
o1003,u003,book,education,59,paid
o1004,u001,headset,digital,299,refund
o1005,u004,coffee,food,45,paid
o1006,u005,monitor,digital,1299,paid
o1007,u002,notebook,education,18,paid
o1008,u006,ssd,digital,499,paid
o1009,u003,pen,education,9,cancel
o1010,u004,tea,food,36,paid
EOF
cat > "$LOCAL5/users.csv" <<'EOF'
user_id,city,level
u001,Baotou,A
u002,Hohhot,B
u003,Ordos,B
u004,Baotou,C
u005,Chifeng,A
u006,Tongliao,B
EOF
echo "课程数据已生成：$LOCAL5"
ls -lh "$LOCAL5"
