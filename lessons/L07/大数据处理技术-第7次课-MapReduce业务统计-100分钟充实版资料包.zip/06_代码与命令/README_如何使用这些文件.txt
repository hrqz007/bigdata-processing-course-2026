这些文件按照课堂顺序编号。

建议学生：
1. 先阅读03_学生上机操作手册。
2. 再按00→07顺序打开命令文件。
3. 命令文件中的#开头文字是中文注释，不会执行；可以整段复制到bash终端。
4. Java源码不要在Windows本地运行，必须放到VS Code Remote SSH连接后的Ubuntu虚拟机目录。
5. 遇到start-dfs.sh找不到、NameNode不起、Connection refused时立即停下找教师。
6. 禁止执行hdfs namenode -format。
