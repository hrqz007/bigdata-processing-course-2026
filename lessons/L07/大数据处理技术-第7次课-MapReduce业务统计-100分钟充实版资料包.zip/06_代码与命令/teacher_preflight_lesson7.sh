#!/usr/bin/env bash
# 第7次课教师课前只读预检脚本
# 只检查环境，不修改配置、不启动/停止服务、不删除数据。

set +e

echo "===== 当前用户/主机 ====="
whoami
hostname

echo "===== Java / Hadoop ====="
java -version 2>&1 | head -n 2
javac -version 2>&1
hadoop version 2>&1 | head -n 1

echo "===== 路径 ====="
echo "HADOOP_HOME=$HADOOP_HOME"
command -v hadoop || true
command -v start-dfs.sh || true
command -v stop-dfs.sh || true

echo "===== 当前Java进程（只查看） ====="
jps 2>/dev/null || true

echo "===== 课程目录 ====="
ls -ld ~/bigdata_course 2>/dev/null || echo "~/bigdata_course 尚不存在（可在课堂创建）"

echo "===== 预检结束 ====="
