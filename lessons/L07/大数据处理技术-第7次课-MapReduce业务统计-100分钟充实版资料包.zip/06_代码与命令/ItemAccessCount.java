package com.dblab.bigdata;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * 第7次课示例1：统计每个商品ID在数据中出现的记录数。
 *
 * 输入CSV：user_id,item_id,behavior,event_time
 * 例如：u001,i101,pv,2026-09-13T10:00:01
 *
 * Mapper输出：
 *   (i101, 1)
 *   (i103, 1)
 *   (i102, 1)
 *
 * Shuffle会把相同key的数据组织到一起，Reducer再求和。
 */
public class ItemAccessCount {

    /** Mapper：从一行CSV中取出item_id字段，并输出(item_id, 1)。 */
    public static class ItemMapper
            extends Mapper<LongWritable, Text, Text, IntWritable> {

        // IntWritable是Hadoop对int的可序列化封装。
        // 所有正常业务记录都贡献1次计数，所以复用同一个ONE对象。
        private static final IntWritable ONE = new IntWritable(1);

        // 输出key会反复变化，例如i101、i102、i103、i104。
        private final Text outKey = new Text();

        @Override
        protected void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {

            // value是一整行CSV文本。
            String line = value.toString().trim();

            // 空行没有统计意义，直接跳过。
            if (line.isEmpty()) {
                return;
            }

            // 第一行是表头，不是业务记录。
            // 如果不跳过，最终结果会错误地把表头中的item_id也当作一个商品ID。
            if (line.startsWith("user_id,")) {
                return;
            }

            // 按逗号切分：
            // fields[0] = user_id
            // fields[1] = item_id
            // fields[2] = behavior
            // fields[3] = event_time
            String[] fields = line.split(",");

            // 防止坏数据导致数组越界。
            if (fields.length < 4) {
                return;
            }

            // 本程序的“统计维度”是item_id。
            String itemId = fields[1].trim();

            // 如果item_id为空，则跳过。
            if (itemId.isEmpty()) {
                return;
            }

            // 把商品ID作为key。
            outKey.set(itemId);

            // 输出(key, 1)，例如(i101,1)。
            context.write(outKey, ONE);
        }
    }

    /** Reducer：把同一个key对应的一组1相加。 */
    public static class SumReducer
            extends Reducer<Text, IntWritable, Text, IntWritable> {

        private final IntWritable result = new IntWritable();

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;

            // 例如key=i101，values可能是[1,1,1,1,1]。
            for (IntWritable value : values) {
                sum += value.get();
            }

            result.set(sum);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {
        // 必须提供两个参数：HDFS输入路径、HDFS输出路径。
        if (args.length != 2) {
            System.err.println("Usage: ItemAccessCount <input> <output>");
            System.exit(2);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "item access count");

        // 告诉Hadoop主类在哪里。
        job.setJarByClass(ItemAccessCount.class);

        // 指定Mapper和Reducer。
        job.setMapperClass(ItemMapper.class);
        job.setReducerClass(SumReducer.class);

        // Mapper最终输出、Reducer最终输出的key/value类型。
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // args[0]来自命令行第1个路径参数：HDFS输入目录。
        FileInputFormat.addInputPath(job, new Path(args[0]));

        // args[1]来自命令行第2个路径参数：HDFS输出目录。
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        // 提交Job并等待完成；成功返回0，失败返回1。
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
