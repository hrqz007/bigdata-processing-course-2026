#!/usr/bin/env bash
# 只读预检：不改配置、不启动/停止服务、不格式化。
echo '=== OS ==='
cat /etc/os-release | head -n 3

echo '\n=== USER / HOST ==='
whoami
hostname

echo '\n=== JAVA ==='
java -version 2>&1 | head -n 3

echo '\n=== HADOOP ==='
hadoop version 2>&1 | head -n 2

echo "HADOOP_HOME=$HADOOP_HOME"
command -v hadoop || true
command -v start-dfs.sh || true
command -v stop-dfs.sh || true

echo '\n=== EXISTENCE ==='
ls -l /usr/local/hadoop/bin/hadoop 2>/dev/null || true
ls -l /usr/local/hadoop/sbin/start-dfs.sh 2>/dev/null || true

echo '\n=== CURRENT JAVA PROCESSES ==='
jps 2>/dev/null || true
