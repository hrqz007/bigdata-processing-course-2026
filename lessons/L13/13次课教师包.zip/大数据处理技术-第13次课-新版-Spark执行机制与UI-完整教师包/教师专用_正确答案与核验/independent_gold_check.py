# -*- coding: utf-8 -*-
"""L13教材独立Gold核算：纯Python标准库，不需要Spark。教师专用。"""
import csv
from collections import Counter,defaultdict
from pathlib import Path
root=Path(__file__).resolve().parent.parent
orders=list(csv.DictReader((root/'09_演示数据'/'orders_l12_A.csv').open(encoding='utf-8',newline='')))
products={x['product_id']:x for x in csv.DictReader((root/'09_演示数据'/'products_l12.csv').open(encoding='utf-8',newline=''))}
counts=Counter(r['product_id'] for r in orders if r['status']=='paid')
sums=defaultdict(int)
for row in orders:
    if row['status']=='paid' and row['product_id'] in products:
        product=products[row['product_id']]
        sums[product['category']]+=int(row['quantity'])*int(product['unit_price_yuan'])
assert len(orders)==14
assert sum(counts.values())==12
assert counts==Counter({'p102':3,'p101':2,'p103':2,'p105':2,'p104':1,'p106':1,'p999':1})
assert sum(sums.values())==22155
print('GOLD_OK',sorted(counts.items()), dict(sorted(sums.items())),sum(sums.values()))
