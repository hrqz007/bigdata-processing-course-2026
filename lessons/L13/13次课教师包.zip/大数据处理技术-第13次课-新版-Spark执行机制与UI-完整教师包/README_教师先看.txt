# 第13次课（2026-10-29）｜正式新版｜Spark Job / Stage / Task / Shuffle / Cache / Spark UI

这是第13次课**最新正式教学设计**，不再沿用2026-10-19生成的“PairRDD业务统计”旧版。

## 使用优先级
- 第11次课：Spark导论（历史材料）。
- Holmes另用两次实际课堂完成了四个PySpark知识单元（DataFrame对象、Column、统计、保存）。
- 第12次课：最新《RDD补强+HDFS双表Join》修订版优先；此前“RDD文本统计”是历史版本。
- **本第13次课**：解释Spark计算执行层次，并观察真实UI；不重教Join/API。
- 第14次课建议Spark独立综合能力验收，随后进入Flink。

## 师生使用
- 教师：先读00执行总览 → 02教师教程 → 10预检 → 01PPT与11逐页讲稿。
- 学生：先读03操作手册，准备code/和data/（运行所需文件）；按照07_逐段复制命令里的01→02→03→04顺序逐步运行。
- 教师完整包中的08_中文注释源码、09_演示数据是运行文件的同字节镜像；**直接运行请使用code/和data/**，不必再手工新建一个新版本。
- 不提供供学生一键执行的.sh脚本。Python源码保留全面中文注释。
- 全班每次重启虚拟机后先连接VS Code Remote SSH；本课使用local[2]、本地CSV，无须启动HDFS/YARN。
- 运行Spark前请确认Driver/Worker使用相同Python（历史VM有系统Python3.10与Anaconda3.11.4混用故障）。

## 运行顺序（VS Code远程Ubuntu终端）
1. mkdir -p ~/bigdata_course/spark/lesson13_execution/{code,data}
2. 在远程文件树把本包code/下的两个.py、data/下的两个.csv复制到对应目录。
3. 打开07_逐段复制命令/01_远程确认与Spark_Python检查.txt，逐段复制。
4. 运行02_A级_RDD的JobStage与UI观察.txt，保持程序停在“按回车”处。
5. 在VS Code Ports转发4040/应用日志真实端口，Windows浏览器观察Jobs/Stages/Storage，再按回车。
6. 运行04_A级_DataFrame执行计划与Cache.txt，并在Spark UI中查看SQL/Storage。
7. 余时完成05_B级参数改变；按06正确收尾。

## 教师预演与真实验收界限
- 本包已通过Python语法解析、原始CSV独立Gold（paid=12、7个商品、DataFrame金额合计22155）、PPT渲染与溢出检测、DOCX渲染及ZIP CRC。
- **尚未在Holmes真实Ubuntu22.04 + Spark3.5.9 + Java8u371环境实跑两个Spark应用与4040 UI。** 必须教师课前完成一次，不能把静态检查标为真实端到端通过。
- 分区与Stage数量需记录学生机器真实UI值，不得虚构固定Job/Stage ID；小数据不作性能加速证明。

## 官方依据（Spark3.5.9）
- https://spark.apache.org/docs/3.5.9/rdd-programming-guide.html
- https://spark.apache.org/docs/3.5.9/monitoring.html
- https://spark.apache.org/docs/3.5.9/web-ui.html
- https://spark.apache.org/docs/3.5.9/sql-performance-tuning.html
