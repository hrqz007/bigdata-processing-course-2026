# -*- coding: utf-8 -*-
"""L13-A：通过小订单文件观察RDD的Job/Stage/Task/Shuffle/Cache。

在 VS Code Remote SSH 的Ubuntu远程终端执行（不是Windows PowerShell）：
  /usr/local/spark/bin/spark-submit --master 'local[2]' \
    code/00_rdd_stage_ui.py --shuffle-partitions 4 --hold-ui

说明：
- 本程序复用第12课 orders_l12_A.csv；不需要HDFS、YARN或Hive。
- --hold-ui使程序运行后停在“按回车”处，方便从Windows浏览器打开Spark UI。
- 如果出现Python Driver/Worker版本不一致，先按命令01统一当前终端的解释器。
"""

import argparse                  # 解析命令行参数。
from operator import add         # add(a,b)就是把两个整数相加。
from pathlib import Path         # 处理Ubuntu文件路径。
from pyspark.sql import SparkSession  # Spark程序入口，前面已学过。

# 一、解释命令行参数；不同的分区数用来比较Task数量。
parser = argparse.ArgumentParser(description="L13观察Spark的RDD调度过程")
parser.add_argument("--shuffle-partitions", type=int, choices=[2, 4], default=4,
                    help="Shuffle完成后的RDD分区数；课堂用2或4对照")
parser.add_argument("--hold-ui", action="store_true",
                    help="程序结束前等待按回车，方便观察Spark UI")
args = parser.parse_args()

# 二、用__file__定位项目目录，不依赖学生当前在哪个文件夹打开VS Code。
project_root = Path(__file__).resolve().parent.parent
input_path = project_root / "data" / "orders_l12_A.csv"
if not input_path.is_file():
    raise FileNotFoundError(f"找不到订单CSV：{input_path}。请检查data文件夹。")

# 三、创建Spark会话。local[2]由外面的spark-submit指定：一台VM、两条本地线程。
spark = SparkSession.builder.appName("L13_RDD_Job_Stage_Shuffle").getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN")  # 教学时减少INFO信息；关键错误仍会显示。

try:
    print("[1] 输入文件：", input_path)
    print("[2] Spark UI：", sc.uiWebUrl or "未启用或不可用")
    print("[3] 本次指定的Shuffle目标分区数：", args.shuffle_partitions)

    # 四、textFile由Spark读取Ubuntu本地文件，返回的是RDD，而不是普通Python列表。
    # minPartitions=4是“建议最少分区数”，不是任何文件都保证恰好4个。
    raw = sc.textFile(input_path.resolve().as_uri(), minPartitions=4)
    print("[4] 原始RDD的实际分区数：", raw.getNumPartitions())

    # 五、Transformation1：过滤CSV表头；这一步还没有真正执行计算。
    rows = raw.filter(lambda line: not line.startswith("order_id,"))

    # 六、Transformation2：教学CSV无嵌入逗号，按逗号拆分后得到字段列表。
    # 一般生产CSV请用Spark DataFrameReader，不要用split解析复杂CSV。
    cells = rows.map(lambda line: line.strip().split(","))

    # 七、Transformation3：只保留status=paid的订单。
    # 字段下标：0订单id，1用户id，2商品id，3购买数量，4订单状态。
    paid = cells.filter(lambda row: len(row) == 5 and row[4] == "paid")

    # 八、Transformation4：生成Pair RDD (商品ID, 1)，为同一商品计数。
    pairs = paid.map(lambda row: (row[2], 1))
    print("[5] pairs分区数：", pairs.getNumPartitions())

    # 九、Wide transformation：reduceByKey需要把相同商品编号聚集到一起。
    # 通常会引入Shuffle边界。参数只调本次分区，不改Spark全局设置。
    by_product = pairs.reduceByKey(add, numPartitions=args.shuffle_partitions)
    print("[6] reduceByKey后的RDD分区数：", by_product.getNumPartitions())

    # 十、在执行Action之前打印依赖关系；通常能看到ShuffledRDD。
    lineage = by_product.toDebugString()
    if isinstance(lineage, bytes):
        lineage = lineage.decode("utf-8", errors="replace")
    print("[7] RDD依赖/Lineage（观察ShuffledRDD）：\n", lineage)
    print("[8] 已创建Transformation，但还没有对by_product执行collect/count。")

    # 十一、cache只是标记待缓存；首次Action真正计算并填充缓存。
    # 这是教学小RDD；并不承诺小数据性能一定变快。
    by_product.cache()
    sc.setJobGroup("L13_RDD_COLLECT", "L13第一次Action：按商品汇总并填充缓存")
    result = sorted(by_product.collect())  # Action：Driver拿到本课7个小统计结果。
    print("[9] 统计结果（商品ID，已支付订单次数）：", result)
    print("[10] 结果总数：", sum(n for _, n in result))

    # 十二、第二个Action复用已经缓存的RDD；用于观察UI的Storage/Jobs。
    sc.setJobGroup("L13_CACHE_REUSE", "L13第二次Action：复用缓存")
    distinct_products = by_product.count()
    print("[11] 已支付订单涉及商品种类：", distinct_products)
    print("[12] Cache标志：", by_product.is_cached)

    # 十三、Spark UI仍需程序活着才能浏览；让学生先打开Ports再回车。
    if args.hold_ui:
        print("\n[观察暂停] 保持这个终端不关闭。现在打开VS Code Ports转发Spark UI端口。")
        print("            在Jobs、Stages、Storage中观察后，回到终端按回车退出。")
        try:
            input("按回车结束并清理缓存 > ")
        except EOFError:
            print("无交互输入，继续正常清理。")
finally:
    try:
        # 离开课堂前清除缓存，释放Executor内存；不改系统配置。
        if "by_product" in locals():
            by_product.unpersist(blocking=True)
    finally:
        spark.stop()
        print("[收尾] spark.stop()已执行；进程退出后4040页面可能关闭。")
