# -*- coding: utf-8 -*-
"""L13-B：从第12次课的DataFrame Join观察物理计划、Shuffle与Cache。

本程序不再次教授Join语法本身，而是解释“Join + GroupBy会怎样被Spark执行”。

启动命令：
  /usr/local/spark/bin/spark-submit --master 'local[2]' \
    code/01_dataframe_plan_cache.py --shuffle-partitions 4 --hold-ui

实际执行计划由Spark版本、数据特征、优化器决定；不要要求每人Stage ID完全相同。
为便于课堂观察，本例在本次SparkSession中关闭AQE（不修改全局配置）。
"""

import argparse                    # 读取命令行参数。
from pathlib import Path           # 通过__file__定位本地CSV。
from pyspark.sql import SparkSession, functions as F  # DataFrame与函数API。
from pyspark.sql.types import (StructType, StructField,
                               StringType, IntegerType, LongType)

parser = argparse.ArgumentParser(description="L13 DataFrame执行计划与Cache")
parser.add_argument("--shuffle-partitions", type=int, choices=[2, 4], default=4)
parser.add_argument("--hold-ui", action="store_true")
args = parser.parse_args()

root = Path(__file__).resolve().parent.parent
orders_file = root / "data" / "orders_l12_A.csv"
products_file = root / "data" / "products_l12.csv"
for path in (orders_file, products_file):
    if not path.is_file():
        raise FileNotFoundError(f"文件不存在：{path}。请确认data目录已传入Ubuntu。")

# 一、只对本次Spark应用设置4或2个SQL Shuffle初始分区。
# 课堂关闭AQE只是为了使执行计划更稳定；生产环境通常不建议盲目关闭。
spark = (SparkSession.builder
         .appName("L13_DataFrame_PhysicalPlan_Cache")
         .config("spark.sql.shuffle.partitions", str(args.shuffle_partitions))
         .config("spark.sql.adaptive.enabled", "false")
         .getOrCreate())
spark.sparkContext.setLogLevel("WARN")

try:
    print("[1] Spark UI：", spark.sparkContext.uiWebUrl or "不可用")
    print("[2] SQL Shuffle目标分区数：", spark.conf.get("spark.sql.shuffle.partitions"))
    print("[3] 本次AQE：", spark.conf.get("spark.sql.adaptive.enabled"))

    # 二、数据结构与L12一致；明确定义Schema，不依赖猜测类型。
    orders_schema = StructType([
        StructField("order_id", StringType()),
        StructField("user_id", StringType()),
        StructField("product_id", StringType()),
        StructField("quantity", IntegerType()),
        StructField("status", StringType()),
    ])
    products_schema = StructType([
        StructField("product_id", StringType()),
        StructField("product_name", StringType()),
        StructField("category", StringType()),
        StructField("unit_price_yuan", LongType()),
    ])
    orders = spark.read.option("header", True).schema(orders_schema).csv(str(orders_file))
    products = spark.read.option("header", True).schema(products_schema).csv(str(products_file))

    # 三、继续第12课“已支付订单与商品表左连接”的业务，不重做业务课。
    paid = orders.filter(F.col("status") == "paid")
    joined = paid.join(products, on="product_id", how="left")
    matched = joined.filter(F.col("product_name").isNotNull())

    # 四、汇总按标价估算的金额；该口径不等于真实成交金额。
    summary = (matched
               .withColumn("line_estimate_yuan", F.col("quantity") * F.col("unit_price_yuan"))
               .groupBy("category")
               .agg(F.sum("line_estimate_yuan").alias("estimated_amount_yuan"))
               .orderBy("category"))

    # 五、EXPLAIN只显示计划，不等于业务查询已经全部执行。
    # 找Exchange / SortMergeJoin / BroadcastHashJoin / HashAggregate等关键词。
    print("\n[4] 物理执行计划（以本机实际显示为准）：")
    summary.explain(mode="formatted")

    # 六、show是Action，会真正启动Spark Job。打开4040 SQL/Jobs/Stages观察。
    spark.sparkContext.setJobGroup("L13_DF_SUMMARY", "L13执行Join和聚合得到估算金额")
    print("\n[5] DataFrame按类别汇总：")
    summary.show(100, truncate=False)

    # 七、缓存joined（12条已支付订单）供多次查询复用。
    # cache()只是标记，接下来的count()才会计算并填充缓存。
    joined.cache()
    spark.sparkContext.setJobGroup("L13_DF_CACHE_FIRST", "L13第一次计算并建立缓存")
    print("[6] joined的实际行数：", joined.count())
    spark.sparkContext.setJobGroup("L13_DF_CACHE_REUSE", "L13第二次Action复用joined缓存")
    print("[7] 未匹配订单数：", joined.filter(F.col("product_name").isNull()).count())
    print("[8] 已缓存joined：", joined.is_cached)

    if args.hold_ui:
        print("\n[观察暂停] 可以查看Spark UI的SQL、Jobs、Stages、Storage标签。")
        print("            任务完成后回车关闭应用；本程序不会删除HDFS原始数据。")
        try:
            input("按回车退出 > ")
        except EOFError:
            pass
finally:
    try:
        if "joined" in locals():
            joined.unpersist(blocking=True)
    finally:
        spark.stop()
        print("[收尾] 已释放DataFrame缓存并停止Spark会话。")
