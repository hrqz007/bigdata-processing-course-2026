#!/usr/bin/env bash
set -u

echo '========== Lesson 8 Teacher Preflight =========='
echo '[1] Host/user/path'
whoami
hostname
pwd

echo
echo '[2] Java/Hadoop/Maven'
java -version 2>&1 | head -n 2
hadoop version 2>&1 | head -n 2
mvn -version 2>&1 | head -n 5

echo
echo '[3] Important commands'
for cmd in start-dfs.sh stop-dfs.sh start-yarn.sh stop-yarn.sh hdfs yarn jps; do
  printf '%-18s : ' "$cmd"
  command -v "$cmd" || echo 'NOT FOUND'
done

echo
echo '[4] YARN config snippets'
grep -n -A2 -B1 'mapreduce.framework.name\|mapreduce.application.classpath' \
  "$HADOOP_HOME/etc/hadoop/mapred-site.xml" 2>/dev/null || echo 'mapred-site.xml missing or not configured'
grep -n -A2 -B1 'yarn.nodemanager.aux-services\|yarn.nodemanager.env-whitelist' \
  "$HADOOP_HOME/etc/hadoop/yarn-site.xml" 2>/dev/null || echo 'yarn-site.xml missing or not configured'

echo
echo '[5] Current Java daemons'
jps || true

echo
echo '[6] Ports 9000/9870/8088'
ss -lnt | grep -E ':(9000|9870|8088)\b' || echo 'No target ports are listening now (may simply mean services are stopped)'

echo
echo '[7] Maven Central reachability (fast check)'
python3 - <<'PY'
import urllib.request
url='https://repo.maven.apache.org/maven2/'
try:
    with urllib.request.urlopen(url, timeout=5) as r:
        print('Maven Central reachable:', r.status)
except Exception as e:
    print('Maven Central check failed:', e)
PY

echo '=================================================='
