第6次课修订重点

1. 已根据教师真实测试结果确认 WordCount 输出正确。
2. 由于每次课都会重新启动虚拟机，本课第一阶段固定加入 HDFS 启动与健康检查。
3. 所有教师材料、学生材料、Shell脚本、Java源码均增加中文注释和“目的—含义—正常结果—故障判断”。
4. 本课采用当前已经验证可用的 LocalJobRunner 跑通 MapReduce；暂不强行启动YARN。
5. 明确解释 _SUCCESS、part-r-00000 和四个关键MapReduce Counters。
6. 不执行 hdfs namenode -format。
