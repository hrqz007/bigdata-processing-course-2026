"""以标准库csv检查从HDFS下载的各part文件，避免依赖Spark自身结论。"""
import csv,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
expected=json.loads((root/'gold/independent_gold.json').read_text())['summary']
rows=[]
for part in sorted((root/'validation/exported_summary_csv').glob('part-*.csv')):
    with part.open() as f:
        for r in csv.DictReader(f):
            for k in ['order_count','quantity_sum','estimated_amount_yuan']:r[k]=int(r[k])
            rows.append(r)
assert sorted(rows,key=lambda x:x['category'])==expected,(rows,expected)
assert sum(r['estimated_amount_yuan'] for r in rows)==22155
print('EXPORTED_CSV_INDEPENDENT_PASS rows=6 estimated_amount_yuan=22155')
print(json.dumps(rows,ensure_ascii=False,indent=2))
