"""只用Python标准库csv独立计算，不依赖Spark程序或复制Spark输出。"""
import csv, json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
with (root / 'data/orders_l12_A.csv').open() as f:
    orders = list(csv.DictReader(f))
with (root / 'data/products_l12.csv').open() as f:
    products = list(csv.DictReader(f))
lookup = {p['product_id']: p for p in products}
assert len(lookup) == len(products) == 6
paid = [o for o in orders if o['status'] == 'paid']
matched = [o for o in paid if o['product_id'] in lookup]
unmatched = [o['order_id'] for o in paid if o['product_id'] not in lookup]
summary = {}
for o in matched:
    p = lookup[o['product_id']]
    r = summary.setdefault(p['category'], dict(order_count=0, quantity_sum=0, estimated_amount_yuan=0))
    r['order_count'] += 1
    r['quantity_sum'] += int(o['quantity'])
    r['estimated_amount_yuan'] += int(o['quantity']) * int(p['unit_price_yuan'])
result = dict(orders=len(orders), products=len(products), paid=len(paid), matched=len(matched),
              unmatched=unmatched, estimated_amount_yuan=sum(r['estimated_amount_yuan'] for r in summary.values()),
              summary=[dict(category=k, **v) for k,v in sorted(summary.items())])
assert (len(orders),len(paid),len(matched),len(unmatched),result['estimated_amount_yuan']) == (14,12,11,1,22155)
assert summary['book'] == dict(order_count=3, quantity_sum=4, estimated_amount_yuan=320)
(root/'gold/independent_gold.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (root/'gold/category_summary.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=['category','order_count','quantity_sum','estimated_amount_yuan'])
    w.writeheader();w.writerows(result['summary'])
print(json.dumps(result,ensure_ascii=False,indent=2))
print('INDEPENDENT_GOLD_PASS')
