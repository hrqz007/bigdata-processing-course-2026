# -*- coding: utf-8 -*-
"""教师参考答案：学生手册展示全文，但学生包不分发此可运行答案文件。"""
import argparse
from pyspark.sql import SparkSession, functions as F

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True, help='runA/detail_by_category根目录')
parser.add_argument('--target', required=True, help='全新runB/book_only目录')
args = parser.parse_args()
assert args.source.startswith('hdfs://') and args.target.startswith('hdfs://')
spark = SparkSession.builder.appName('L16_Book_Exercise').getOrCreate()
spark.sparkContext.setLogLevel('WARN')
try:
    detail = spark.read.parquet(args.source)  # 从分区根目录读取，保留category列。
    book = detail.filter(F.col('category') == 'book')  # 复用已学filter。
    book.write.mode('errorifexists').parquet(args.target)  # 旧目录存在即报错，不覆盖。
    reread = spark.read.parquet(args.target)  # 回读磁盘结果，而非只看内存。
    reread.orderBy('order_id').show(truncate=False)
    reread.printSchema()
    assert reread.count() == 3
    assert reread.agg(F.sum('quantity')).first()[0] == 4
    assert reread.agg(F.sum('estimated_amount_yuan')).first()[0] == 320
    from collections import Counter  # 教师提供的核验工具，仅适合本节小样本。
    assert Counter(tuple(r) for r in book.collect()) == Counter(tuple(r) for r in reread.select(*book.columns).collect())
    print('BOOK_PASS rows=3 quantity=4 estimated_amount_yuan=320')
finally:
    spark.stop()
