#!/usr/bin/env bash
# 教师“只读预检”：不启动/停止/安装服务，不修改Metastore。
# 建议课前一天先在教师母盘手工执行每阶段。
set -u
printf '== VS Code远程机器 ==\n'
whoami;hostname;pwd
printf '== JDK/Hadoop/Hive ==\n'
java -version 2>&1 | head -n 2
hadoop version | head -n 1
command -v beeline || true
command -v schematool || true
printf '== Java进程 ==\n'
jps
printf '== HDFS连接地址 ==\n'
hdfs getconf -confKey fs.defaultFS
printf '== 分区练习只改/user/hadoop/bigdata/lesson10 ==\n'
printf '== 教师务必确认：前一课orders_ext仍在、Hive Derby可连接 ==\n'
