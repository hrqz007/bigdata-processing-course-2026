#!/usr/bin/env bash
# 目的：把两天订单数据分别放入dt=日期的HDFS目录；再上传维度表。
# 关键概念：每一个dt=2026-09-28目录就是一个“分区候选目录”。
# 文件必须放在“数据目录”中，不能把脚本文件传进Hive LOCATION目录。
set -euo pipefail
WORK="$HOME/bigdata_course/hive/lesson10"
# 教师发放包通过VS Code复制到此目录：脚本在command/，数据在data/。
DAT="$WORK/data"
ROOT="/user/$USER/bigdata/lesson10"
PART="$ROOT/orders_part"
DIM="$ROOT/dim_category"
for f in "$DAT/orders_2026-09-28.csv" "$DAT/orders_2026-09-29.csv" "$DAT/dim_category.csv"; do
  if [[ ! -f "$f" ]];then echo "找不到本地文件：$f；请检查VS Code上传步骤。";exit 1;fi
done
printf '=== 两天订单行数（没有表头）===\n'
wc -l "$DAT/orders_2026-09-28.csv" "$DAT/orders_2026-09-29.csv"
printf '=== 1. 创建HDFS分区目录 ===\n'
# -p：若父目录不存在则一并创建；已存在不报错。
hdfs dfs -mkdir -p "$PART/dt=2026-09-28" "$PART/dt=2026-09-29" "$DIM"
printf '=== 2. 上传两天订单文件 ===\n'
# -put：Linux本地文件上传HDFS；-f：覆盖同名旧文件，方便重复上课。
hdfs dfs -put -f "$DAT/orders_2026-09-28.csv" "$PART/dt=2026-09-28/"
hdfs dfs -put -f "$DAT/orders_2026-09-29.csv" "$PART/dt=2026-09-29/"
printf '=== 3. 上传商品类别维度表 ===\n'
hdfs dfs -put -f "$DAT/dim_category.csv" "$DIM/"
printf '=== 4. 查看HDFS结果 ===\n'
hdfs dfs -ls -R "$ROOT"
printf '\n请看清：订单数据分在两个dt=日期的文件夹；dim_category单独存放。\n'
