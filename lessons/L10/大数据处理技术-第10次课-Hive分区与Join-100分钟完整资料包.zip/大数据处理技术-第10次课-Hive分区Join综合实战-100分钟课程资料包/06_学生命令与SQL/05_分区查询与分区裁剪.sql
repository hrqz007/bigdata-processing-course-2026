-- 本段目标：知道PARTITION是什么，WHERE dt如何帮助Hive只读取某天的目录。
USE bigdata_course;

-- 看真实分区列表；应有dt=2026-09-28和dt=2026-09-29。
SHOW PARTITIONS orders_part_l10;

-- 只看9月28日：预期12条。dt列是从分区目录推断的，不必在CSV每行写它。
SELECT dt, COUNT(*) AS order_count
FROM orders_part_l10
WHERE dt='2026-09-28'
GROUP BY dt;

-- 只看9月29日：预期10条。
SELECT dt, COUNT(*) AS order_count
FROM orders_part_l10
WHERE dt='2026-09-29'
GROUP BY dt;

-- 两天分别按支付状态计数：观察GROUP BY dt、status的组合。
-- 预期28日 paid10/cancelled2；29日 paid8/cancelled2。
SELECT dt, status, COUNT(*) AS n
FROM orders_part_l10
GROUP BY dt, status
ORDER BY dt, status;

-- 看执行计划：关注Partition和Filter等关键词，版本不同输出排版会有差别。
-- EXPLAIN不是真正执行查询，不代表测出了真实加速倍数。
EXPLAIN
SELECT order_id, user_id, category
FROM orders_part_l10
WHERE dt='2026-09-29';
