-- 本段目标：把分区 + JOIN + WHERE + GROUP BY + SUM整合成真实业务统计。
USE bigdata_course;

-- 全部订单：22条；已支付18条；取消4条。
SELECT status, COUNT(*) AS order_count
FROM orders_part_l10
GROUP BY status
ORDER BY status;

-- 每日已支付成交金额：9月28日22710；9月29日18262。
SELECT dt,
       COUNT(*) AS paid_orders,
       ROUND(SUM(amount),2) AS paid_amount
FROM orders_part_l10
WHERE status='paid'
GROUP BY dt
ORDER BY dt;

-- 加入维度表中文名称：用LEFT JOIN保证sport仍保留在结果里。
-- COALESCE：优先使用中文名称；NULL时显示“未维护类别”。
SELECT o.category,
       COALESCE(d.category_cn,'未维护类别') AS category_name_cn,
       COUNT(*) AS paid_orders,
       ROUND(SUM(o.amount),2) AS paid_amount
FROM orders_part_l10 o
LEFT JOIN dim_category_l10 d
ON o.category=d.category
WHERE o.status='paid'
GROUP BY o.category, d.category_cn
ORDER BY paid_amount DESC;

-- 看未匹配的sport究竟多少笔、金额多少。
SELECT o.category,
       COUNT(*) AS paid_orders,
       ROUND(SUM(o.amount),2) AS paid_amount
FROM orders_part_l10 o
LEFT JOIN dim_category_l10 d
ON o.category=d.category
WHERE o.status='paid' AND d.category IS NULL
GROUP BY o.category;
