#!/usr/bin/env bash
# 目的：确认Hive正常，不重新安装、不重新初始化Derby Metastore。
# 先进入Ubuntu的远程终端；脚本按第9课相同JDBC方式连接。
set -euo pipefail
command -v beeline  # Hive SQL客户端，应找到命令路径
command -v schematool
# 打印Hive数据库和表信息；如果报Derby locked，关闭其他Beeline/Hive会话后重试。
beeline -u 'jdbc:hive2://' -n "$USER" \
  -e "SHOW DATABASES; USE bigdata_course; SHOW TABLES; DESCRIBE orders_ext; SELECT order_id, category, status FROM orders_ext LIMIT 3;"
echo '验收点：bigdata_course中能找到第9课的orders_ext，且可以读出3条样例订单。'
