#!/usr/bin/env bash
# 目的：结束本节课时停止后台服务，避免直接关虚拟机；不删除表和HDFS文件。
# 若其他人共享同一Hadoop集群，不要随意停止公共服务；本课默认每人独立单节点VM。
set -euo pipefail
printf '停止YARN（ResourceManager、NodeManager）...\n'
stop-yarn.sh
printf '停止HDFS（NameNode、DataNode等）...\n'
stop-dfs.sh
printf '完成后用jps观察：Hadoop/YARN进程应不再出现。\n'
jps
