#!/usr/bin/env bash
# 目的：每次重新启动虚拟机，都要重新检查HDFS、YARN、Hive。只在必要时启动服务。
# 运行位置：Windows VS Code已通过Remote-SSH连接Ubuntu后，底部远程Linux终端。
# 注意：本脚本不格式化、不清空数据库、不修改任何Hadoop配置文件。
set -euo pipefail
printf '\n[1/7] 当前登录身份与主机\n'
whoami             # 预期hadoop
hostname           # 预期dblab
printf '\n[2/7] 检查Hive是否安装\n'
command -v beeline # 若找不到，请先找教师，不要自行重装Hive
command -v hdfs
printf '\n[3/7] 检查HDFS进程\n'
# jps会显示所有Java进程；NameNode/DataNode/SecondaryNameNode属于HDFS。
jps
# 无NameNode时才执行start-dfs.sh；已启动时不重复启动。
if ! jps | grep -q ' NameNode$'; then
  echo 'NameNode尚未启动，启动HDFS...'
  start-dfs.sh
fi
printf '\n[4/7] 等待NameNode退出安全模式（最多60秒）\n'
# Safe Mode ON时，HDFS不能正常写入；新启动需要等待DataNode上报块。
for i in 1 2 3 4 5 6; do
  if hdfs dfsadmin -safemode get 2>&1 | grep -q 'OFF'; then break; fi
  sleep 10
done
hdfs dfsadmin -safemode get
printf '\n[5/7] 检查DataNode\n'
# 正常的单机伪分布式环境应显示Live datanodes (1)。
hdfs dfsadmin -report | grep 'Live datanodes'
printf '\n[6/7] 检查或启动YARN\n'
# YARN负责资源管理；若ResourceManager未启动，再调用start-yarn.sh。
if ! jps | grep -q ' ResourceManager$'; then
  echo 'ResourceManager未运行，启动YARN...'
  start-yarn.sh
fi
jps
# 注意：如果下面没有RUNNING节点，不要继续长时间运行GROUP BY/Join。
yarn node -list
printf '\n[7/7] 验收提示\n'
echo '确认：NameNode、DataNode、ResourceManager、NodeManager存在；Safe Mode OFF；RUNNING节点至少1个。'
