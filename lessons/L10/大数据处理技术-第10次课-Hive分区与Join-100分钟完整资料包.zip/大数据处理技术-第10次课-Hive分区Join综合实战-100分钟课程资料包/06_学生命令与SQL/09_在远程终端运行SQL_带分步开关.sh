#!/usr/bin/env bash
# 目的：学生不用在Hive交互界面一条条敲SQL，只需选择stage，运行对应注释版SQL文件。
# 这不是重装Hive，重复执行SQL查询不会删除HDFS原始订单文件。
# 用法示例：bash command/09_在远程终端运行SQL_带分步开关.sh 1
set -euo pipefail
ROOT="$HOME/bigdata_course/hive/lesson10"
SQL_DIR="$ROOT/command"
STAGE="${1:-}"
case "$STAGE" in
  1) FILE="$SQL_DIR/04_创建Hive分区表与维度表.sql";;
  2) FILE="$SQL_DIR/05_分区查询与分区裁剪.sql";;
  3) FILE="$SQL_DIR/06_INNER_JOIN和LEFT_JOIN.sql";;
  4) FILE="$SQL_DIR/07_订单综合业务分析.sql";;
  5) FILE="$SQL_DIR/08_加深任务_仅提前完成者运行.sql";;
  *) echo '参数只能填1/2/3/4/5，例如：bash command/09_在远程终端运行SQL_带分步开关.sh 1';exit 2;;
esac
if [[ ! -f "$FILE" ]];then echo "找不到SQL文件：$FILE；请检查上传目录。";exit 1;fi
printf '\n即将执行（请先阅读该SQL中的中文注释）：%s\n' "$FILE"
# -u JDBC连接URL：沿用第9课嵌入式本地Beeline方式。
# -n 用户名；-f 从SQL文件执行。不需要另开HiveServer2。
beeline -u 'jdbc:hive2://' -n "$USER" -f "$FILE"
