-- 本段目标：理解Join=按照共同字段把两张表“对上”；了解INNER/LEFT差别。
USE bigdata_course;

-- 步骤1：先分别看订单类别和维度表的类别。
-- 这里sport出现在订单里，但维度表没有sport，后面用作对照。
SELECT DISTINCT category FROM orders_part_l10 ORDER BY category;
SELECT * FROM dim_category_l10;

-- 步骤2：INNER JOIN（内连接）。
-- o.category=d.category 的意思是：两张表里category值相同的行合并。
-- sport在维度表找不到，结果中会消失；注意这是内连接的规则，不是数据“丢失”。
SELECT o.order_id, o.category, d.category_cn, o.amount
FROM orders_part_l10 o
INNER JOIN dim_category_l10 d
ON o.category=d.category
WHERE o.dt='2026-09-29'
ORDER BY o.order_id;

-- 步骤3：LEFT JOIN（左连接）。
-- 保留左表（订单表）所有匹配条件的行。
-- sport在右表找不到对应值时，d.category_cn会是NULL。
SELECT o.order_id, o.category, d.category_cn, o.amount
FROM orders_part_l10 o
LEFT JOIN dim_category_l10 d
ON o.category=d.category
WHERE o.dt='2026-09-29'
ORDER BY o.order_id;

-- 步骤4：查询Join后的“未匹配”订单，定位分类字典缺失问题。
-- IS NULL意味着右表没能匹配到对应类别。
SELECT o.order_id, o.category, o.amount
FROM orders_part_l10 o
LEFT JOIN dim_category_l10 d
ON o.category=d.category
WHERE o.dt='2026-09-29'
  AND d.category IS NULL
ORDER BY o.order_id;
