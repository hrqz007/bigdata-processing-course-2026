-- 第10课第一次新建分区表和维度表。适用于Hive 3.1.3。
-- 本SQL不删除原始HDFS数据，不操作第9课的orders_ext。
USE bigdata_course;

-- 外部表：保留HDFS原始文件，Hive只记录结构和目录映射。
-- IF NOT EXISTS：重复运行时不报错。字段类型和第9课一致。
CREATE EXTERNAL TABLE IF NOT EXISTS orders_part_l10 (
  order_id STRING,        -- 订单编号
  user_id STRING,         -- 用户编号
  item_id STRING,         -- 商品编号
  category STRING,        -- 商品类别（phone/book/...）
  amount DOUBLE,          -- 订单金额（带小数）
  status STRING,          -- paid=已支付；cancelled=已取消
  event_time STRING       -- 订单时间；本次先按STRING处理
)
-- dt是分区字段：dt=Data Date，数据所属日期标签。
-- 非分区数据CSV里不需要额外再写这一列。
PARTITIONED BY (dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hadoop/bigdata/lesson10/orders_part';

-- 查询Hive记录了几个分区（第一次可能没有）。
SHOW PARTITIONS orders_part_l10;

-- 学生先用HDFS命令建dt=...文件夹，因此Hive Metastore还不一定认识它们。
-- MSCK REPAIR TABLE：扫描目录并把分区“登记”进Metastore；不会自动创建订单数据。
MSCK REPAIR TABLE orders_part_l10;

-- 再查：预期登记两个日期分区。
SHOW PARTITIONS orders_part_l10;

-- 维度表：一行说明一个类别的中文名称和部门，类别是Join键。
-- CSV第一行有字段名，因此要跳过表头。
CREATE EXTERNAL TABLE IF NOT EXISTS dim_category_l10 (
  category STRING,        -- 比如phone
  category_cn STRING,     -- 比如手机
  department STRING       -- 比如数码
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hadoop/bigdata/lesson10/dim_category'
TBLPROPERTIES ('skip.header.line.count'='1');

-- 基础验收：分区表共22条，维度表共4条（缺sport故意用于Left Join实验）。
SELECT COUNT(*) AS order_count FROM orders_part_l10;
SELECT COUNT(*) AS category_count FROM dim_category_l10;
