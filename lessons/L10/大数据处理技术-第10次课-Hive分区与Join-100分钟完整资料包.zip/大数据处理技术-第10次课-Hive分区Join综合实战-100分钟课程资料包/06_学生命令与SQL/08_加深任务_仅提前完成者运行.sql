-- B/C级提高任务：观察“分区过滤 + 连接”执行计划；不要求全班在100分钟全部做完。
USE bigdata_course;

-- 只查询9月29日的paid订单，按用户统计金额。
SELECT user_id, ROUND(SUM(amount),2) AS paid_amount
FROM orders_part_l10
WHERE dt='2026-09-29' AND status='paid'
GROUP BY user_id
ORDER BY paid_amount DESC;

-- 检查分区过滤 + JOIN如何转成执行计划（只是查看计划，不直接返回业务结果）。
EXPLAIN
SELECT o.order_id, d.category_cn
FROM orders_part_l10 o
LEFT JOIN dim_category_l10 d
ON o.category=d.category
WHERE o.dt='2026-09-29';

-- 对照没有dt过滤的查询，思考读取范围可能有什么变化。
EXPLAIN
SELECT o.order_id, d.category_cn
FROM orders_part_l10 o
LEFT JOIN dim_category_l10 d
ON o.category=d.category;
