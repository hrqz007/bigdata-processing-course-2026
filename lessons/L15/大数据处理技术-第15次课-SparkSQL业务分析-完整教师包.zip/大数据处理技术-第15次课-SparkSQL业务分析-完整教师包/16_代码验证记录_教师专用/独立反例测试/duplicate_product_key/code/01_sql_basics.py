# -*- coding: utf-8 -*-
"""第15课：用熟悉订单系统整理SELECT、WHERE、GROUP BY及SQL/DataFrame等价核验。
课堂分段：--step select 或 --step group；教师预检可用--step all。
复制练习文件仍放code目录，不修改原CSV。collect仅用于本课14行小数据。
"""
import argparse  # 读取阶段选项，便于每次只运行一个课堂任务。
import json  # 仅供已提供的证据保存设施使用，本课不讲解JSON写文件。
from pathlib import Path  # 从脚本位置找项目，不依赖终端当前目录。
from pyspark.sql import SparkSession, functions as F  # SQL会话与已学DataFrame函数。


def compare_results(label, sql_result, df_result):  # 用14行教学数据核验两种写法。
    assert sql_result.columns == df_result.columns, label + "列名或列顺序不同"  # 先统一列。
    assert sql_result.dtypes == df_result.dtypes, label + "数据类型不同"  # 再核对类型。
    sql_rows = sql_result.collect()  # 查询已按相同键排序，取回全部小数据行。
    df_rows = df_result.collect()  # 列表保留重复行，不能改成set集合。
    assert sql_rows == df_rows, label + "结果不同，请检查筛选、分组和关联口径"  # 不只比较行数。
    print("CHECK_PASS=" + label)  # 这是两写法一致，不等于题目要求自动正确。
    return [row.asDict() for row in sql_rows]  # 转成字典便于保存课堂证据。


# 下面是已提供的运行设施，课堂只改有Q编号的业务段。
parser = argparse.ArgumentParser(description="第15课Spark SQL业务对照")  # 创建参数解析器。
parser.add_argument("--step", choices=["select", "group", "all"], default="all")  # 选择课堂阶段。
parser.add_argument("--output-dir", default="outputs", help="相对项目根的证据目录")  # 可给练习另存目录。
args = parser.parse_args()  # 读取本次命令。
root = Path(__file__).resolve().parent.parent  # code的上一级就是本项目。
output_dir = Path(args.output_dir)  # 支持相对目录或绝对目录。
if not output_dir.is_absolute():  # 相对路径一律以项目根为基准。
    output_dir = root / output_dir  # 避免从别的工作目录启动时找错位置。
orders_file = root / "data" / "orders_l12_A.csv"  # 沿用第12/13课订单样例。
if not orders_file.is_file():  # 先检查CSV确实已复制到Ubuntu。
    raise FileNotFoundError("缺少订单文件：" + str(orders_file))  # 失败时不伪造成功。
APP_NAME = "L15_SQL_Basics"  # 在Spark应用列表中辨认本程序。
spark = (SparkSession.builder.appName(APP_NAME)  # 课堂应用名。
         .config("spark.sql.shuffle.partitions", "2")  # 小型教学数据只设2个SQL分区。
         .getOrCreate())  # 使用命令传入的local[2]，不写入全局配置。
spark.sparkContext.setLogLevel("WARN")  # 不屏蔽真正错误。
results = {"step": args.step, "spark_version": spark.version}  # 保存运行上下文。
try:  # 业务执行失败也会进入finally释放Spark会话。
    # 读取桥接：按已给定字段说明读入熟悉CSV；Schema与存储格式留到第16课。
    orders = (spark.read.option("header", True)  # CSV首行是列名。
              .schema("order_id STRING, user_id STRING, product_id STRING, quantity INT, status STRING")  # 已提供字段说明。
              .csv(orders_file.as_uri()))  # 显式file:///路径，不误走默认HDFS。
    orders.createOrReplaceTempView("orders")  # 让当前SparkSession用SQL名字orders访问DataFrame。
    print("TEMP_VIEW=orders; MASTER=" + spark.sparkContext.master)  # 记录本应用上下文。

    if args.step in ("select", "all"):  # 只运行SELECT阶段或全部阶段。
        # Q1-SQL / Q1_SQL：已支付且至少买2件的订单，取三列。
        q1_sql = spark.sql("""
            SELECT order_id, product_id, quantity
            FROM orders
            WHERE status = 'paid' AND quantity >= 2
            ORDER BY order_id
        """)  # SQL结果本身也是DataFrame；ORDER BY使展示和核验顺序确定。
        # Q1-DF / Q1_DATAFRAME：使用前课已学filter、select和orderBy写同一需求。
        q1_df = (orders.filter((F.col("status") == "paid") & (F.col("quantity") >= 2))  # 两条件都成立。
                 .select("order_id", "product_id", "quantity")  # 列名和顺序与SQL相同。
                 .orderBy("order_id"))  # 与SQL按同一订单编号排序。
        print("\nQ1：已支付且quantity>=2的订单（修改练习时按本人条件解释）")  # 输出题目段落。
        q1_sql.show(truncate=False)  # show触发执行，展示真实结果。
        results["Q1"] = compare_results("Q1", q1_sql, q1_df)  # 比较完整结果而非只看总数。
        print("Q1_ROWS=", len(results["Q1"]))  # 当前筛选的订单行数。
        print("Q1_QUANTITY=", sum(row["quantity"] for row in results["Q1"]))  # 当前筛选的件数。

    if args.step in ("group", "all"):  # 只运行GROUP BY阶段或全部阶段。
        # Q2-SQL / Q2_SQL：每种商品的已支付订单行数与购买件数。
        q2_sql = spark.sql("""
            SELECT product_id, COUNT(*) AS order_count, SUM(quantity) AS total_quantity
            FROM orders
            WHERE status = 'paid'
            GROUP BY product_id
            ORDER BY product_id
        """)  # COUNT(*)数订单行，SUM(quantity)累加件数，不能混为一谈。
        # Q2-DF / Q2_DATAFRAME：同一筛选、分组键、聚合函数、列名和排序。
        q2_df = (orders.filter(F.col("status") == "paid")  # 先选已支付订单。
                 .groupBy("product_id")  # 按商品编号分组。
                 .agg(F.count("*").alias("order_count"),  # 每行计一次订单。
                      F.sum("quantity").alias("total_quantity"))  # 累加每行购买件数。
                 .orderBy("product_id"))  # 按商品编号稳定展示。
        print("\nQ2：按商品统计已支付订单行数与件数")  # 输出段落标签。
        q2_sql.show(truncate=False)  # 执行并显示分组结果。
        results["Q2"] = compare_results("Q2", q2_sql, q2_df)  # 两种写法必须完整一致。
        print("Q2_ORDER_COUNT=", sum(row["order_count"] for row in results["Q2"]))  # 分组后的订单数之和。
        print("Q2_TOTAL_QUANTITY=", sum(row["total_quantity"] for row in results["Q2"]))  # 分组后的件数之和。

    # 以下只是教师提供的证据设施，不作为第16课数据写出知识提前讲授。
    output_dir.mkdir(parents=True, exist_ok=True)  # 创建本地课堂证据目录。
    evidence = output_dir / ("01_" + args.step + ".json")  # 分阶段保存，避免相互覆盖。
    evidence.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")  # 保存真实结果。
    print("EVIDENCE_JSON=" + str(evidence))  # 告知证据文件所在位置。
finally:  # 无论成功或失败均执行。
    spark.stop()  # 仅停止当前Spark会话；临时视图随会话结束，不写成持久表。
