# -*- coding: utf-8 -*-
"""第15课环境健康检查：必须实际执行Python Worker，而不只比较环境变量。"""
import platform  # 打印本机操作系统，避免把云端结果当作教师VM结果。
import sys  # 读取Driver实际使用的Python。
from pyspark.sql import SparkSession  # 建立真实Spark会话。

spark = SparkSession.builder.appName("L15_Environment_Health").getOrCreate()  # master由命令传入。
spark.sparkContext.setLogLevel("WARN")  # 保留警告，减少无关INFO日志。
try:  # 无论成功失败，最后都停止本应用。
    sc = spark.sparkContext  # 获取SparkContext以执行Python Worker任务。
    print("OS=", platform.platform())  # 记录真实操作系统。
    print("DRIVER_PYTHON=", sys.executable, sys.version.split()[0])  # 记录Driver路径与版本。
    print("SPARK_VERSION=", spark.version)  # 记录实际Spark版本。
    print("SPARK_MASTER=", sc.master)  # 应是local[2]，不是两台机器。
    print("JAVA_VERSION=", sc._jvm.java.lang.System.getProperty("java.version"))  # 只读JVM版本。
    worker_versions = sc.parallelize([1, 2], 2).map(lambda x: (sys.executable, sys.version.split()[0])).collect()  # 真正启动Worker。
    total = sc.parallelize([1, 2, 3, 4], 2).map(lambda x: x * 2).sum()  # Worker参与计算。
    assert all(v[1].split(".")[:2] == sys.version.split()[0].split(".")[:2] for v in worker_versions), "Driver/Worker的Python主次版本不同"  # 检查版本。
    assert total == 20, "Worker计算结果应为20"  # 核验实际计算。
    print("WORKER_PYTHON=", worker_versions)  # 输出真实Worker信息。
    print("WORKER_SUM=", total)  # 应为20。
    print("HEALTH_PASS")  # 只有前面检查全部通过才打印。
finally:  # 正常和异常都会执行。
    spark.stop()  # 仅结束本Spark应用，不起停HDFS/YARN。
