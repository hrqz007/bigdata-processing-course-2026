# -*- coding: utf-8 -*-
"""教师专用：在云端隔离环境复跑最终源码；不代表教师Ubuntu母盘验收。"""
from pathlib import Path
import subprocess, os, sys, json, hashlib, datetime, platform
root = Path(__file__).resolve().parent.parent
logs = root / '16_代码验证记录_教师专用'
refs = root / '教师专用_正确答案与核验'
base = (root / 'code/01_sql_basics.py').read_text(encoding='utf-8')
a1 = base.replace("quantity >= 2", "quantity >= 3").replace('F.col("quantity") >= 2', 'F.col("quantity") >= 3')
a2 = base.replace("WHERE status = 'paid'  --", "WHERE status = 'paid' AND quantity >= 2  --").replace('orders.filter(F.col("status") == "paid")', 'orders.filter((F.col("status") == "paid") & (F.col("quantity") >= 2))')
(refs / '01_A1_教师修改参考.py').write_text(a1, encoding='utf-8')
(refs / '02_A2_教师修改参考.py').write_text(a2, encoding='utf-8')
env = os.environ.copy()
env.update(JAVA_HOME='/tmp/l15jdk8', PYSPARK_PYTHON='/tmp/l15spark/bin/python', PYSPARK_DRIVER_PYTHON='/tmp/l15spark/bin/python', SPARK_LOCAL_IP='127.0.0.1')
env['PATH'] = env['JAVA_HOME'] + '/bin:' + env['PATH']
submit = '/tmp/l15spark/bin/spark-submit'
tests = [
 ('04_final_health', 'code/00_environment_health.py', [], ['HEALTH_PASS']),
 ('05_final_select', 'code/01_sql_basics.py', ['--step','select'], ['CHECK_PASS=Q1']),
 ('06_final_group', 'code/01_sql_basics.py', ['--step','group'], ['CHECK_PASS=Q2']),
 ('07_final_join', 'code/02_sql_join_compare.py', ['--step','join'], ['CHECK_PASS=Q3_INNER','CHECK_PASS=Q3_LEFT','CHECK_PASS=Q3_UNMATCHED']),
 ('08_final_summary', 'code/02_sql_join_compare.py', ['--step','summary'], ['CHECK_PASS=Q4']),
 ('09_final_basics_all', 'code/01_sql_basics.py', ['--step','all'], ['CHECK_PASS=Q1','CHECK_PASS=Q2']),
 ('10_final_join_all', 'code/02_sql_join_compare.py', ['--step','all'], ['CHECK_PASS=Q3_INNER','CHECK_PASS=Q3_LEFT','CHECK_PASS=Q4']),
 ('11_A1', '教师专用_正确答案与核验/01_A1_教师修改参考.py', ['--step','select','--output-dir','outputs/a1'], ['CHECK_PASS=Q1']),
 ('12_A2', '教师专用_正确答案与核验/02_A2_教师修改参考.py', ['--step','group','--output-dir','outputs/a2'], ['CHECK_PASS=Q2']),
]
report = {'environment': {'os': platform.platform(), 'python': subprocess.check_output(['/tmp/l15spark/bin/python','-V'],text=True).strip(), 'java': subprocess.check_output(['/tmp/l15jdk8/bin/java','-version'],stderr=subprocess.STDOUT,text=True).strip(), 'spark': '3.5.9', 'master': 'local[2]'}, 'scope': '云端隔离环境测试，非教师Ubuntu22.04/JDK8u371母盘验收。', 'tests': [], 'source_sha256': {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'code').glob('*.py'))}}
for name, script, args, tokens in tests:
    cmd = [submit, '--master', 'local[2]', str(root/script)] + args
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    # summary有意从/tmp启动，验证不依赖当前目录。
    cwd = '/tmp' if name == '08_final_summary' else str(root)
    result=subprocess.run(cmd,env=env,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
    (logs/(name+'.log')).write_text('COMMAND='+repr(cmd)+'\nCWD='+cwd+'\n'+result.stdout+'\nEXIT_CODE='+str(result.returncode)+'\n',encoding='utf-8')
    passed=result.returncode==0 and all(t in result.stdout for t in tokens)
    report['tests'].append({'name':name,'script':script,'args':args,'cwd':cwd,'start_utc':start,'exit_code':result.returncode,'required_tokens':tokens,'passed':passed})
    (logs/'test_evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(name,'PASS' if passed else 'FAIL',flush=True)
    if not passed: sys.exit(1)
check=subprocess.run([sys.executable,str(refs/'independent_gold_check.py'),'--check-dir','outputs'],cwd=str(root),text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(logs/'13_independent_gold.log').write_text(check.stdout,encoding='utf-8')
assert check.returncode==0, check.stdout
gold=json.loads((refs/'independent_gold_result.json').read_text(encoding='utf-8'))
a1data=json.loads((root/'outputs/a1/01_select.json').read_text())
a2data=json.loads((root/'outputs/a2/01_group.json').read_text())
assert a1data['Q1']==gold['advanced_teacher_only']['A1_Q1_quantity_ge_3']
assert a2data['Q2']==gold['advanced_teacher_only']['A2_Q2_paid_quantity_ge_2']
report['independent_comparison']='基础6个JSON及两练习完整结果均与标准库独立计算相同。'
report['all_passed']=True
(logs/'test_evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('ALL_CLOUD_VALIDATION_PASS',flush=True)
