# -*- coding: utf-8 -*-
"""仅用Python标准库从原始CSV独立重算金标准，不调用Spark或学生程序。
运行：python3 教师专用_正确答案与核验/independent_gold_check.py
教师测试后：追加 --check-dir outputs，比对已产生的分段或all证据。
"""
import argparse  # 指定需要比对的证据目录。
import csv  # 用另一条计算路径读取原始CSV。
import hashlib  # 记录数据的字节指纹。
import json  # 保存独立核验结果。
from collections import defaultdict  # 实现独立分组汇总。
from pathlib import Path  # 定位当前教师包。

parser = argparse.ArgumentParser(description="第15课独立金标准计算")  # 不使用Spark。
parser.add_argument("--check-dir", help="可选：检查该目录下的Spark JSON证据")  # 根目录相对路径。
args = parser.parse_args()  # 接收命令参数。
root = Path(__file__).resolve().parent.parent  # 从教师核验文件位置定位包根。
with (root / "data/orders_l12_A.csv").open(encoding="utf-8", newline="") as f:  # 读订单。
    orders = list(csv.DictReader(f))  # 一行转一个普通Python字典。
with (root / "data/products_l12.csv").open(encoding="utf-8", newline="") as f:  # 读商品。
    products = list(csv.DictReader(f))  # 与Spark API完全独立。
for row in orders:  # 本金标准仅适用随包提供的数据。
    row["quantity"] = int(row["quantity"])  # 显式把件数转换为整数。
for row in products:  # 商品价为整元。
    row["unit_price_yuan"] = int(row["unit_price_yuan"])  # 不采用浮点近似。
assert len({r["order_id"] for r in orders}) == len(orders), "原CSV订单编号重复"  # 保证样例一行一订单。
assert len({r["product_id"] for r in products}) == len(products), "原CSV商品编号重复"  # 保证本样例维度键唯一。
by_id = {r["product_id"]: r for r in products}  # 商品索引。
paid = sorted([r for r in orders if r["status"] == "paid"], key=lambda r: r["order_id"])  # 只要已支付。
q1 = [{k: r[k] for k in ("order_id", "product_id", "quantity")} for r in paid if r["quantity"] >= 2]  # 独立筛选投影。

def group_orders(rows):  # 使用普通循环完成分组。
    values = defaultdict(lambda: [0, 0])  # 每组保存订单行数与件数。
    for row in rows:  # 遍历当前口径的订单。
        values[row["product_id"]][0] += 1  # COUNT(*)的含义。
        values[row["product_id"]][1] += row["quantity"]  # SUM(quantity)的含义。
    return [{"product_id": key, "order_count": value[0], "total_quantity": value[1]} for key, value in sorted(values.items())]  # 统一顺序。

left, inner, unmatched = [], [], []  # 独立构造三组关联结果。
amounts = defaultdict(int)  # 记录各类别估算金额。
for order in paid:  # 所有已支付订单都进入LEFT范围。
    product = by_id.get(order["product_id"])  # 找不到返回None。
    row = {k: order[k] for k in ("order_id", "product_id", "quantity")}  # 取左侧三列。
    row.update({"category": product["category"] if product else None, "unit_price_yuan": product["unit_price_yuan"] if product else None})  # 模拟右侧缺失NULL。
    left.append(row)  # LEFT始终保留左侧订单。
    if product:  # INNER只保留找到商品的订单。
        inner.append(row)  # 保留匹配明细。
        amounts[product["category"]] += order["quantity"] * product["unit_price_yuan"]  # 按标价累加。
    else:  # 单独记录缺失商品。
        unmatched.append({"order_id": order["order_id"], "product_id": order["product_id"]})  # 异常名单。
q4 = [{"category": k, "estimated_amount_yuan": v} for k, v in sorted(amounts.items())]  # 类别结果。
gold = {"Q1": q1, "Q2": group_orders(paid), "Q3_INNER": inner, "Q3_LEFT": left, "Q3_UNMATCHED": unmatched, "Q4": q4}  # 全部基础金标准。
assert len(orders) == 14 and len(products) == 6 and len(paid) == 12  # 手工常量复核基础规模。
assert len(q1) == 5 and sum(r["quantity"] for r in q1) == 11  # 手工复核Q1。
assert sum(r["quantity"] for r in paid) == 18  # 已支付件数。
assert len(inner) == 11 and sum(r["quantity"] for r in inner) == 17  # 匹配件数。
assert unmatched == [{"order_id": "o008", "product_id": "p999"}]  # 核对缺失商品。
assert dict(amounts) == {"phone": 5998, "book": 320, "computer": 14997, "accessory": 360, "home": 180, "sports": 300}  # 手工类别金额。
assert sum(amounts.values()) == 22155  # 全部匹配金额。
checked = []  # 记录实际比较过的Spark文件。
if args.check_dir:  # 可选择在Spark运行后核验。
    folder = Path(args.check_dir)  # 解析目录参数。
    if not folder.is_absolute(): folder = root / folder  # 相对包根。
    files = sorted(folder.glob("0[12]_*.json"))  # 只比对本课的证据文件。
    assert files, "指定目录没有基础Spark证据，不能声称比对通过"  # 防止空检查误报。
    for path in files:  # 逐文件比较实际业务字段。
        data = json.loads(path.read_text(encoding="utf-8"))  # 读取真实Spark输出。
        keys = [key for key in gold if key in data]  # 取本次实际运行的题目。
        assert keys, str(path) + "没有业务结果"  # 无结果不能过。
        for key in keys: assert data[key] == gold[key], str(path) + "与独立金标准不同：" + key  # 比较完整列表。
        checked.append({"file": str(path.relative_to(root)), "queries": keys, "pass": True})  # 留下可追溯记录。
advanced = {"A1_Q1_quantity_ge_3": [{k: r[k] for k in ("order_id", "product_id", "quantity")} for r in paid if r["quantity"] >= 3], "A2_Q2_paid_quantity_ge_2": group_orders([r for r in paid if r["quantity"] >= 2])}  # 仅教师保存练习答案。
report = {"gold": gold, "advanced_teacher_only": advanced, "checked_spark_files": checked, "data_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / "data").glob("*.csv")}, "note": "纯Python独立重算；未列在checked_spark_files中的项目不代表已实际比对。"}  # 明确验收边界。
output = Path(__file__).resolve().parent / "independent_gold_result.json"  # 教师专用文件。
output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")  # 保存重算结果。
print("INDEPENDENT_GOLD_PASS", output)  # 仅在所有断言通过后报告。
print("CHECKED_SPARK_FILES=", len(checked))  # 0意味着只算金标准，未比对Spark。
