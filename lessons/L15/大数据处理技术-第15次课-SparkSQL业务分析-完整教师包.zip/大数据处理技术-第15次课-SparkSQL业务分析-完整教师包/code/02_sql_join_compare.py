# -*- coding: utf-8 -*-
"""第15课：系统整理INNER/LEFT JOIN和类别金额估算，核对SQL/DataFrame结果。
课堂分段：--step join 或 --step summary；教师预检可用--step all。
金额为数量乘商品表当前标价的估算，不含折扣/退款，不能称为实际销售收入。
"""
import argparse  # 读取阶段选项，便于每次只运行一个课堂任务。
import json  # 仅供已提供的证据保存设施使用，本课不讲解JSON写文件。
from pathlib import Path  # 从脚本位置找项目，不依赖终端当前目录。
from pyspark.sql import SparkSession, functions as F  # SQL会话与已学DataFrame函数。


def compare_results(label, sql_result, df_result):  # 用14行教学数据核验两种写法。
    assert sql_result.columns == df_result.columns, label + "列名或列顺序不同"  # 先统一列。
    assert sql_result.dtypes == df_result.dtypes, label + "数据类型不同"  # 再核对类型。
    sql_rows = sql_result.collect()  # 查询已按相同键排序，取回全部小数据行。
    df_rows = df_result.collect()  # 列表保留重复行，不能改成set集合。
    assert sql_rows == df_rows, label + "结果不同，请检查筛选、分组和关联口径"  # 不只比较行数。
    print("CHECK_PASS=" + label)  # 这是两写法一致，不等于题目要求自动正确。
    return [row.asDict() for row in sql_rows]  # 转成字典便于保存课堂证据。


# 下面是已提供的运行设施，课堂只改有Q编号的业务段。
parser = argparse.ArgumentParser(description="第15课Spark SQL业务对照")  # 创建参数解析器。
parser.add_argument("--step", choices=["join", "summary", "all"], default="all")  # 选择课堂阶段。
parser.add_argument("--output-dir", default="outputs", help="相对项目根的证据目录")  # 可给练习另存目录。
args = parser.parse_args()  # 读取本次命令。
root = Path(__file__).resolve().parent.parent  # code的上一级就是本项目。
output_dir = Path(args.output_dir)  # 支持相对目录或绝对目录。
if not output_dir.is_absolute():  # 相对路径一律以项目根为基准。
    output_dir = root / output_dir  # 避免从别的工作目录启动时找错位置。
orders_file = root / "data" / "orders_l12_A.csv"  # 沿用第12/13课订单样例。
if not orders_file.is_file():  # 先检查CSV确实已复制到Ubuntu。
    raise FileNotFoundError("缺少订单文件：" + str(orders_file))  # 失败时不伪造成功。
products_file = root / "data" / "products_l12.csv"  # 沿用商品维度表。
if not products_file.is_file():  # 在创建Spark前报告路径问题。
    raise FileNotFoundError("缺少商品文件：" + str(products_file))  # 不自动猜测HDFS路径。
APP_NAME = "L15_SQL_Join_Compare"  # 应用名称。
spark = (SparkSession.builder.appName(APP_NAME)  # 课堂应用名。
         .config("spark.sql.shuffle.partitions", "2")  # 小型教学数据只设2个SQL分区。
         .getOrCreate())  # 使用命令传入的local[2]，不写入全局配置。
spark.sparkContext.setLogLevel("WARN")  # 不屏蔽真正错误。
results = {"step": args.step, "spark_version": spark.version}  # 保存运行上下文。
try:  # 业务执行失败也会进入finally释放Spark会话。
    # 读取桥接：按已给定字段说明读入熟悉CSV；Schema与存储格式留到第16课。
    orders = (spark.read.option("header", True)  # CSV首行是列名。
              .schema("order_id STRING, user_id STRING, product_id STRING, quantity INT, status STRING")  # 已提供字段说明。
              .csv(orders_file.as_uri()))  # 显式file:///路径，不误走默认HDFS。
    orders.createOrReplaceTempView("orders")  # 让当前SparkSession用SQL名字orders访问DataFrame。
    print("TEMP_VIEW=orders; MASTER=" + spark.sparkContext.master)  # 记录本应用上下文。
    products = (spark.read.option("header", True)  # 商品CSV首行也是列名。
                .schema("product_id STRING, product_name STRING, category STRING, unit_price_yuan BIGINT")  # 已给字段说明。
                .csv(products_file.as_uri()))  # 只读Ubuntu本地文件。
    products.createOrReplaceTempView("products")  # SQL用products访问此DataFrame。
    paid = orders.filter(F.col("status") == "paid")  # DataFrame写法的已支付订单。
    # 本课商品编号唯一，所以LEFT JOIN不会因右表重复键扩增订单行；这不是所有Join的保证。
    assert products.count() == products.select("product_id").distinct().count(), "商品表product_id不唯一，先检查输入"  # 给教师预检。

    if args.step in ("join", "all"):  # 本段展示INNER与LEFT的保留范围。
        # Q3-INNER-SQL：只保留在商品表能找到商品的已支付订单。
        inner_sql = spark.sql("""
            SELECT o.order_id, o.product_id, o.quantity, p.category, p.unit_price_yuan  -- 选择输出列；AS为结果列命名。
            FROM orders AS o  -- 指定当前会话中的临时视图。
            INNER JOIN products AS p ON o.product_id = p.product_id  -- ON指定关联键；只保留两侧匹配行。
            WHERE o.status = 'paid'  -- 仅保留满足本次业务条件的行。
            ORDER BY o.order_id  -- 固定输出顺序，便于逐行比较。
        """)  # o/p为表别名，避免两表同名列混淆。
        # Q3-INNER-DF：on字符串保留一个product_id列，列选择与SQL一致。
        inner_df = (paid.join(products, on="product_id", how="inner")  # 只保留匹配记录。
                    .select("order_id", "product_id", "quantity", "category", "unit_price_yuan")  # 同样五列。
                    .orderBy("order_id"))  # 与SQL相同排序。
        print("\nQ3 INNER JOIN：已支付且能匹配商品的订单")  # 解释保留范围。
        inner_sql.show(100, truncate=False)  # 展示全部11行而非仅总数。
        results["Q3_INNER"] = compare_results("Q3_INNER", inner_sql, inner_df)  # 保留重复行核验。
        # Q3-LEFT-SQL：保留左侧所有已支付订单，右侧找不到的列为NULL。
        left_sql = spark.sql("""
            SELECT o.order_id, o.product_id, o.quantity, p.category, p.unit_price_yuan  -- 选择输出列；AS为结果列命名。
            FROM orders AS o  -- 指定当前会话中的临时视图。
            LEFT JOIN products AS p ON o.product_id = p.product_id  -- ON指定关联键；保留左侧行，右侧缺失补NULL。
            WHERE o.status = 'paid'  -- 仅保留满足本次业务条件的行。
            ORDER BY o.order_id  -- 固定输出顺序，便于逐行比较。
        """)  # status条件只约束左表，没有把右表NULL记录误删。
        # Q3-LEFT-DF：同一关联键，只把关联类型改为left。
        left_df = (paid.join(products, on="product_id", how="left")  # 未匹配左侧订单仍在。
                   .select("order_id", "product_id", "quantity", "category", "unit_price_yuan")  # 与SQL同列。
                   .orderBy("order_id"))  # 与SQL同顺序。
        print("\nQ3 LEFT JOIN：保留全部已支付订单，请找到o008/p999")  # NULL不是商品单价0。
        left_sql.show(100, truncate=False)  # 显示右侧缺失字段。
        results["Q3_LEFT"] = compare_results("Q3_LEFT", left_sql, left_df)  # 核验整个左关联结果。
        # 独立检查未匹配订单：用右表的关联键判定，不把NULL写成字符串'NULL'。
        unmatched_sql = spark.sql("""
            SELECT o.order_id, o.product_id  -- 选择输出列；AS为结果列命名。
            FROM orders AS o  -- 指定当前会话中的临时视图。
            LEFT JOIN products AS p ON o.product_id = p.product_id  -- ON指定关联键；保留左侧行，右侧缺失补NULL。
            WHERE o.status = 'paid' AND p.product_id IS NULL  -- 仅保留满足本次业务条件的行。
            ORDER BY o.order_id  -- 固定输出顺序，便于逐行比较。
        """)  # IS NULL是判断空值的正确语法。
        unmatched_df = (paid.alias("o").join(products.alias("p"), F.col("o.product_id") == F.col("p.product_id"), "left")  # 保留两侧键以判断缺失。
                        .filter(F.col("p.product_id").isNull())  # 未在右表找到关联键。
                        .select(F.col("o.order_id").alias("order_id"), F.col("o.product_id").alias("product_id"))  # 统一列名。
                        .orderBy("order_id"))  # 与SQL相同排序。
        results["Q3_UNMATCHED"] = compare_results("Q3_UNMATCHED", unmatched_sql, unmatched_df)  # 核验异常名单。
        print("UNMATCHED=", results["Q3_UNMATCHED"])  # 本数据应只有o008/p999。
        print("INNER_ROWS=", len(results["Q3_INNER"]), "LEFT_ROWS=", len(results["Q3_LEFT"]))  # 展示行数差异。
        print("INNER_QUANTITY=", sum(row["quantity"] for row in results["Q3_INNER"]), "LEFT_QUANTITY=", sum(row["quantity"] for row in results["Q3_LEFT"]))  # 展示件数差异。

    if args.step in ("summary", "all"):  # 本段按匹配商品的类别汇总估算金额。
        # Q4-SQL / Q4_SQL：INNER JOIN明确排除无标价的未匹配订单。
        q4_sql = spark.sql("""
            SELECT p.category, SUM(o.quantity * p.unit_price_yuan) AS estimated_amount_yuan  -- 选择输出列；AS为结果列命名。
            FROM orders AS o  -- 指定当前会话中的临时视图。
            INNER JOIN products AS p ON o.product_id = p.product_id  -- ON指定关联键；只保留两侧匹配行。
            WHERE o.status = 'paid'  -- 仅保留满足本次业务条件的行。
            GROUP BY p.category  -- 按此字段将明细分成若干组。
            ORDER BY p.category  -- 固定输出顺序，便于逐行比较。
        """)  # 先连接形成明细，再按类别累加数量乘标价。
        # Q4-DF / Q4_DATAFRAME：同一业务使用已学withColumn、groupBy、agg。
        q4_df = (paid.join(products, on="product_id", how="inner")  # 匹配范围与SQL一致。
                 .withColumn("line_estimate_yuan", F.col("quantity") * F.col("unit_price_yuan"))  # 每行标价估算。
                 .groupBy("category")  # 按商品类别分组。
                 .agg(F.sum("line_estimate_yuan").alias("estimated_amount_yuan"))  # 汇总各类别估算。
                 .orderBy("category"))  # 与SQL相同顺序。
        print("\nQ4：按商品当前标价估算金额，不等于实际成交收入")  # 明确业务口径。
        q4_sql.show(truncate=False)  # 展示六个类别。
        results["Q4"] = compare_results("Q4", q4_sql, q4_df)  # 完整结果核验。
        print("ESTIMATED_TOTAL_YUAN=", sum(row["estimated_amount_yuan"] for row in results["Q4"]))  # 汇总本次类别结果。

    # 以下是现成证据设施，不要求学生学习新的存储读写知识。
    output_dir.mkdir(parents=True, exist_ok=True)  # 创建本地证据目录。
    evidence = output_dir / ("02_" + args.step + ".json")  # 不同阶段不同文件。
    evidence.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")  # 只记录实际运行结果。
    print("EVIDENCE_JSON=" + str(evidence))  # 给教师定位证据。
finally:  # 即使核验失败也结束当前应用。
    spark.stop()  # 当前会话的临时视图随会话结束，不成为持久表。
