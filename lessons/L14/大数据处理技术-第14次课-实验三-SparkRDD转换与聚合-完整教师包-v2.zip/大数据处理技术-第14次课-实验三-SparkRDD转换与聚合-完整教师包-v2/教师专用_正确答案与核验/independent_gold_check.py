# -*- coding: utf-8 -*-
"""教师专用v2独立核算：标准库csv与Counter，不导入PySpark或答案脚本。
基础继续核验既有JSON；拔高只核验教师辅助TXT，不要求学生建立新文件协议。
--check-original-baseline只用于原始40条教学数据；变更输入测试时不加。
"""
import argparse                       # 读取输入与待核验文件位置。
import csv                            # 使用标准库独立解析CSV，与Spark的split实现分离。
import json                           # 仅用于基础实验已经存在的结果JSON。
import re                             # 严格检查教师TXT里的正整数文字。
from collections import Counter       # 单机独立计数，不依赖任何Spark中间结果。
from pathlib import Path              # 处理教师本地核验文件。


def require(condition, message):       # 拒绝结构或结果不符合约定的文件。
    if not condition:                 # 不用宽松数值相等代替类型核验。
        raise ValueError("CHECK_ERROR：" + message) # 给出明确错误，退出非零。


def is_nonnegative_int(value):        # bool属于int子类，因此不能只用isinstance。
    return type(value) is int and value >= 0 # 基础计数必须是非负整数。


def validate_basic_schema(actual):    # 保留基础JSON的严格结构与类型核验。
    fields = {"input_data_rows", "valid_rows", "invalid_rows", "behavior_counts", "item_counts"} # 基础既有五字段。
    require(type(actual) is dict and set(actual) == fields, "基础顶层必须恰含五个约定字段。") # 不允许缺键或多键。
    for key in ("input_data_rows", "valid_rows", "invalid_rows"): # 核验三个行数。
        require(is_nonnegative_int(actual[key]), key + "必须为非负整数，不接受float或bool。") # 防止8.0冒充8。
    for key in ("behavior_counts", "item_counts"): # 核验两个分组统计。
        require(type(actual[key]) is dict, key + "必须为对象。") # 不接受数组替代。
        for group, count in actual[key].items(): # 逐项检查键和值。
            require(type(group) is str and group != "", key + "分组键必须为非空字符串。") # ID保持字符串。
            require(is_nonnegative_int(count), key + "计数必须为非负整数，不接受float或bool。") # 保留严格整数规则。


def read_teacher_buy_text(path):      # 只读教师参考保存的辅助TXT，不规定学生输出文件。
    result = {}                       # 按用户保存次数，不依赖文本行顺序。
    with path.open(encoding="utf-8", newline="") as stream: # 空文件代表无购买用户。
        for number, row in enumerate(csv.reader(stream), start=1): # 每行必须正好用户和计数两项。
            require(len(row) == 2, f"教师TXT第{number}行必须为user_id,正整数。") # 无表头或多余字段。
            user_id, count_text = (field.strip() for field in row) # 忽略两字段首尾空白。
            require(user_id != "", f"教师TXT第{number}行用户不能为空。") # 不接受空ID。
            require(re.fullmatch(r"[1-9][0-9]*", count_text) is not None, f"教师TXT第{number}行计数必须为正整数文字。") # 不接受0、float、bool或负数。
            require(user_id not in result, f"教师TXT用户{user_id}出现多次，未形成单一汇总。") # 同一用户只应有一个计数。
            result[user_id] = int(count_text) # 独立转为整数，便于无序结果比较。
    return result                     # 不排序、不排名、不补零。


parser = argparse.ArgumentParser(description="第14课v2独立核验：基础JSON与教师购买计数TXT") # 无需Spark环境。
parser.add_argument("--input", type=Path, required=True) # 原始或教师变更的CSV。
parser.add_argument("--basic-result", type=Path) # 可选核验基础结果JSON。
parser.add_argument("--buy-result", type=Path, help="教师辅助TXT，每行user_id,正整数，无排序要求") # 不是学生新交付协议。
parser.add_argument("--check-original-baseline", action="store_true") # 原始固定金标准核验开关。
args = parser.parse_args()            # 读取参数。
with args.input.open(encoding="utf-8", newline="") as stream: # 从CSV重新核算。
    reader = csv.reader(stream)        # 标准库解析器，不导入学生is_valid函数。
    require(next(reader) == ["event_id", "user_id", "item_id", "behavior"], "CSV表头不符。") # 校验字段顺序。
    rows = [[field.strip() for field in row] for row in reader] # 按契约去字段两端空白。
accepted = []                         # 保存通过独立规则的有效行。
for row in rows:                      # 显式逐条应用相同业务规则。
    if len(row) != 4:                 # 字段数必须恰为4。
        continue                     # 缺字段或多字段都不计入。
    if any(field == "" for field in row): # 四字段必须全部非空。
        continue                     # 不因行为文字是buy就放过空字段。
    if row[3] not in ("pv", "cart", "buy"): # 仅三类教学行为合法。
        continue                     # 排除其他行为。
    accepted.append(row)             # 每条有效行是一件事件，不去重ID。
behaviors = Counter()                # 复核基础行为计数。
items = Counter()                    # 复核基础商品计数。
buy_users = Counter()                # 唯一拔高：只统计有效购买事件对应的用户。
for _, user_id, item_id, behavior in accepted: # 独立遍历有效事件。
    behaviors[behavior] += 1          # 基础行为次数加一。
    items[item_id] += 1               # 基础商品事件数加一。
    if behavior == "buy":            # 仅购买事件才更新用户购买计数。
        buy_users[user_id] += 1       # 同一用户不同商品的购买仍归属于同一用户。
gold_basic = {"input_data_rows": len(rows), "valid_rows": len(accepted), "invalid_rows": len(rows) - len(accepted), "behavior_counts": dict(sorted(behaviors.items())), "item_counts": dict(sorted(items.items()))} # 基础输出保持不变。
if args.check_original_baseline:      # 原始数据额外对照固定金标准。
    expected_basic = {"input_data_rows": 40, "valid_rows": 36, "invalid_rows": 4, "behavior_counts": {"buy": 8, "cart": 8, "pv": 20}, "item_counts": {"I01": 11, "I02": 10, "I03": 8, "I04": 7}} # 沿用基础金标准。
    require(gold_basic == expected_basic, "原始数据基础金标准不符。") # 防止原始CSV被误改。
    require(dict(buy_users) == {"U01": 2, "U02": 2, "U03": 1, "U04": 1, "U06": 2}, "原始数据购买用户金标准不符。") # 无零购买用户，无排名。
if args.basic_result is not None:     # 只验用户明确指定的结果，不假称全部验收。
    actual_basic = json.loads(args.basic_result.read_text(encoding="utf-8")) # 读取原有基础JSON。
    validate_basic_schema(actual_basic) # 先检查结构与严格整数类型。
    require(actual_basic == gold_basic, f"基础结果不符：实际={actual_basic}；独立结果={gold_basic}") # 完整字段比对。
    print("基础JSON_COMPARE_PASS：", args.basic_result) # 说明已比较的文件。
if args.buy_result is not None:       # 教师有辅助TXT时进行购买计数比对。
    actual_buy = read_teacher_buy_text(args.buy_result) # 行顺序不影响正确性。
    require(actual_buy == dict(buy_users), f"购买计数不符：实际={actual_buy}；独立结果={dict(buy_users)}") # 缺用户、多用户、错次数均拒绝。
    print("教师BUY_TEXT_COMPARE_PASS：", args.buy_result) # 不产生新的拔高JSON。
print("[独立基础核算]", json.dumps(gold_basic, ensure_ascii=False)) # 基础既有JSON仅显示在教师终端。
print("[独立购买事件核算]", dict(buy_users)) # 教师可见无排名的小计数结果。
print("INDEPENDENT_CHECK_PASS：仅所列输入与已指定结果文件通过独立核验。") # 不声称教师VM已验收。
