# -*- coding: utf-8 -*-
"""教师专用v2：只统计有效buy事件，按user_id汇总购买事件次数。
不补零、不排序、不排名；不产生学生新JSON协议。禁止放入学生包。
--output是教师可选核验辅助：无表头TXT，每行user_id,正整数，无行顺序要求。
"""
import argparse                       # 读取教师显式指定的本地文件位置。
from operator import add              # 将同一用户的购买事件次数相加。
from pathlib import Path              # 生成明确的本地file URI。
from pyspark.sql import SparkSession  # 只借用会话入口，统计仍使用RDD。

parser = argparse.ArgumentParser(description="教师专用：按用户统计购买事件次数") # 建立参数入口。
parser.add_argument("--input", type=Path, required=True) # 必须指定与基础实验相同的CSV。
parser.add_argument("--output", type=Path, help="仅教师可选：保存无表头user_id,次数文本") # 学生无需遵守此保存格式。
args = parser.parse_args()            # 读取提交命令后面的参数。
input_path = args.input.expanduser().resolve() # 定位Ubuntu本地文件。
if not input_path.is_file():          # 启动Spark前检查路径。
    raise FileNotFoundError(input_path) # 不创建假输入，也不转向HDFS。
spark = SparkSession.builder.appName("L14_V2_Teacher_Buy_Count").getOrCreate() # 创建本程序会话。
sc = spark.sparkContext               # 获取RDD入口。
sc.setLogLevel("WARN")               # 保留警告与错误，降低普通日志噪声。
try:                                  # 无论成功或失败都释放本会话。
    assert sc.master == "local[2]", "本课固定local[2]。" # 不依赖HDFS或YARN服务。
    raw = sc.textFile(input_path.as_uri(), minPartitions=2) # 使用显式file URI读本地CSV。
    header = raw.first()               # 取首行指定表头。
    assert header == "event_id,user_id,item_id,behavior", "表头不符。" # 防止字段错位。
    cells = raw.filter(lambda line: line != header).map(lambda line: [part.strip() for part in line.split(",")]) # 解析限定教学CSV。
    valid = cells.filter(lambda row: len(row) == 4 and all(row) and row[3] in ("pv", "cart", "buy")) # 与基础保持同一有效规则。
    buys = valid.filter(lambda row: row[3] == "buy") # 只保留有效购买事件，不能只见buy就忽略坏行。
    pairs = buys.map(lambda row: (row[1], 1)) # 每次购买事件给所属用户贡献1，不按商品分别输出。
    result = pairs.reduceByKey(add).collect() # 只收集最终小结果，不对输出排序。
    for pair in result:               # 行顺序由本次执行产生，不作为评分依据。
        print("BUY_USER_COUNT", pair) # 显示(user_id,购买事件次数)，仅包含买过的用户。
    if not result:                    # 无有效购买时，空结果本身是正确结果。
        print("BUY_USER_COUNT_EMPTY：没有有效buy事件。") # 不补造零计数用户。
    assert sum(count for _, count in result) == buys.count() # 购买事件计数守恒。
    if args.output is not None:       # 以下仅供教师独立核验，不要求学生掌握新保存协议。
        output = args.output.expanduser().resolve() # 教师显式指定辅助TXT位置。
        output.parent.mkdir(parents=True, exist_ok=True) # 只创建教师项目输出目录。
        output.write_text("".join(f"{user_id},{count}\n" for user_id, count in result), encoding="utf-8") # 无表头、无排序；无buy时为空文件。
        print("[教师核验TXT]", output) # 清楚标记其教师辅助用途。
    print("BUY_EXTENSION_CHECK_PASS：购买事件计数守恒通过。") # 自检通过仍需独立核算。
finally:                              # 不停止无关系统服务。
    spark.stop()                      # 仅释放本程序Spark会话。
