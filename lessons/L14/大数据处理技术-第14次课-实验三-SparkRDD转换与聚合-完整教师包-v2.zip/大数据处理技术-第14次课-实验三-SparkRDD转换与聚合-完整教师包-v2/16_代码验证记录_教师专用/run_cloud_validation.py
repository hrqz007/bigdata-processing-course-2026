"""仅记录v2助手隔离云端复现过程；不是学生课堂命令，不安装任何课堂软件。"""
from pathlib import Path
import ast,copy,hashlib,json,os,subprocess,sys,datetime
ROOT=Path(__file__).resolve().parents[2]
V=ROOT/'teacher_extra/validation'
S=ROOT/'code_data'
T=ROOT/'teacher_extra/教师专用_正确答案与核验'
SPARK='/tmp/l14_spark_test/bin/spark-submit'
ENV=os.environ.copy();ENV.update(JAVA_HOME='/tmp/l14_jre17',PYSPARK_PYTHON='/tmp/l14_spark_test/bin/python',PYSPARK_DRIVER_PYTHON='/tmp/l14_spark_test/bin/python',SPARK_LOCAL_IP='127.0.0.1')
checks=[]
def run(command,log,expected=0):
 p=subprocess.run([str(x) for x in command],env=ENV,capture_output=True,text=True)
 log.parent.mkdir(parents=True,exist_ok=True);log.write_text(p.stdout+p.stderr,encoding='utf-8')
 checks.append({'log':str(log.relative_to(V)),'returncode':p.returncode,'expected':expected})
 if expected==0: assert p.returncode==0,(str(log),p.stderr[-2000:])
 else: assert p.returncode!=0 and 'CHECK_ERROR' in p.stderr,(str(log),p.returncode,p.stdout,p.stderr)
 return p.stdout

def spark(script,*args): return [SPARK,'--master','local[2]',script,*args]
def independent(data,basic,buy,baseline=False):
 command=[sys.executable,T/'independent_gold_check.py','--input',data,'--basic-result',basic,'--buy-result',buy]
 if baseline:command.append('--check-original-baseline')
 return command

out=V/'cloud_outputs';out.mkdir(exist_ok=True)
run(spark(S/'code/00_environment_health.py'),V/'01_cloud_health.log')
run(spark(S/'code/01_rdd_behavior_lab.py','--output-dir',out),V/'02_cloud_basic.log')
data=S/'data/user_behavior_l14.csv'
run(spark(T/'02_teacher_extension_answer.py','--input',data,'--output',out/'teacher_buy_counts.txt'),V/'03_cloud_buy_counts.log')
run(independent(data,out/'basic_results.json',out/'teacher_buy_counts.txt',True),V/'04_independent_compare.log')
stdout=run(spark(T/'02_teacher_extension_answer.py','--input',data),V/'05_stdout_only_reference.log')
stdout_pairs=[ast.literal_eval(line.split(' ',1)[1]) for line in stdout.splitlines() if line.startswith('BUY_USER_COUNT ')]
assert dict(stdout_pairs)=={'U01':2,'U02':2,'U03':1,'U04':1,'U06':2}
print('BASELINE_AND_STDOUT_ONLY_PASS',flush=True)
header='event_id,user_id,item_id,behavior\n'
fixtures={
 'no_buy':header+'E001,U03,I01,pv\nE002,U02,I01,cart\n',
 'invalid_buy_rows':header+'E001,U01,I01,buy\nE002,,I02,buy\nE003,U02,,buy\n,U03,I03,buy\nE005,U04,buy\nE006,U05,I05,buy,extra\nE007,U06,I06,like\nE008,U07,I07,pv\n',
 'same_user_multiple_items':header+'E001,U02,I01,buy\nE002,U02,I02,buy\nE003,U02,I03,buy\n E004 , U01 , I02 , buy \nE005,U02,I04,pv\nE006,U05,I05,cart\n'}
for name,content in fixtures.items():
 case=V/'cases'/name;case.mkdir(parents=True,exist_ok=True);input_file=case/'input.csv';input_file.write_text(content,encoding='utf-8');outputs=case/'outputs';outputs.mkdir(exist_ok=True)
 run(spark(S/'code/01_rdd_behavior_lab.py','--input',input_file,'--output-dir',outputs),case/'basic.log')
 run(spark(T/'02_teacher_extension_answer.py','--input',input_file,'--output',outputs/'teacher_buy_counts.txt'),case/'buy.log')
 run(independent(input_file,outputs/'basic_results.json',outputs/'teacher_buy_counts.txt'),case/'independent.log')
 txt=(outputs/'teacher_buy_counts.txt').read_text()
 actual=dict((u,int(n)) for u,n in (line.split(',') for line in txt.splitlines()))
 expect={'no_buy':{},'invalid_buy_rows':{'U01':1},'same_user_multiple_items':{'U02':3,'U01':1}}[name]
 assert actual==expect,(name,actual)
 if name=='no_buy':assert (outputs/'teacher_buy_counts.txt').stat().st_size==0
 print(name,'PASS',flush=True)

# 顺序不是要求：反转教师TXT的行顺序仍必须通过独立核验。
q=V/'text_contract_checks';q.mkdir(exist_ok=True)
lines=(out/'teacher_buy_counts.txt').read_text().splitlines()
reversed_file=q/'reversed_order.txt';reversed_file.write_text('\n'.join(reversed(lines))+'\n')
run([sys.executable,T/'independent_gold_check.py','--input',data,'--buy-result',reversed_file],q/'reversed_order.log')
# 这些只是教师辅助TXT的防误验收，不是要求学生学习新保存协议。
negatives={
 'float_count':'U01,2.0\nU02,2\nU03,1\nU04,1\nU06,2\n',
 'bool_count':'U01,True\n',
 'duplicate_user':'\n'.join(lines)+'\nU01,2\n',
 'zero_buyer':'\n'.join(lines)+'\nU05,0\n',
 'negative_count':'U01,-2\n',
 'extra_column':'U01,2,extra\n',
 'wrong_total':'U01,9\nU02,2\nU03,1\nU04,1\nU06,2\n',
 'missing_buyer':'U01,2\nU02,2\nU03,1\nU04,1\n'}
for name,content in negatives.items():
 f=q/(name+'.txt');f.write_text(content,encoding='utf-8')
 run([sys.executable,T/'independent_gold_check.py','--input',data,'--buy-result',f],q/(name+'.log'),expected=1)
# 基础原有严格JSON验证仍保留：等值float与bool不得冒充整数。
base=json.loads((out/'basic_results.json').read_text());base['input_data_rows']=40.0
f=q/'basic_float_counterexample.json';f.write_text(json.dumps(base));run([sys.executable,T/'independent_gold_check.py','--input',data,'--basic-result',f],q/'basic_float_counterexample.log',expected=1)
edge=V/'cases/no_buy';base=json.loads((edge/'outputs/basic_results.json').read_text());base['behavior_counts']['cart']=True
f=q/'basic_bool_counterexample.json';f.write_text(json.dumps(base));run([sys.executable,T/'independent_gold_check.py','--input',edge/'input.csv','--basic-result',f],q/'basic_bool_counterexample.log',expected=1)

protected=json.loads((V/'protected_baseline_sha256.json').read_text())
for rel,digest in protected.items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest
for p in list((S/'code').glob('*.py'))+list(T.glob('*.py')):
 for version in [(3,10),(3,11)]:ast.parse(p.read_text(),feature_version=version)
(V/'test_steps.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print('ALL_V2_CLOUD_CHECKS_PASS',flush=True)
