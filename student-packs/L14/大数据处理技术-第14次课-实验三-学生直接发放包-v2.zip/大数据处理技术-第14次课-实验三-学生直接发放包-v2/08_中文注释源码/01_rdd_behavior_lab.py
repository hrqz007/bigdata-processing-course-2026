# -*- coding: utf-8 -*-
"""实验三基础参考：小型用户行为日志的RDD转换、过滤、键值聚合与核验。
按手册复制完整基础为本人副本，分段读懂并核验；本课基础不要求从零猜写算法。
教学CSV限定：UTF-8、4列、无引号、无字段内逗号/换行；复杂CSV不能照搬split。
命令：/usr/local/spark/bin/spark-submit --master 'local[2]' code/01_rdd_behavior_lab.py
"""
import argparse                       # 读取可选输入与输出位置。
import json                           # 保存可核验的小结果，不保存原始大数据。
from operator import add              # add(a,b)返回两个计数的和。
from pathlib import Path              # 处理本地路径并生成显式file URI。
from pyspark.sql import SparkSession  # 创建会话；统计过程只使用RDD API。


def is_valid(row):                    # 字段顺序：事件ID、用户ID、商品ID、行为。
    return len(row) == 4 and all(row) and row[3] in {"pv", "cart", "buy"} # 三项必须同时满足。


root = Path(__file__).resolve().parent.parent # 由脚本位置找项目根目录，不依赖终端当前目录。
parser = argparse.ArgumentParser(description="第14课实验三：RDD行为统计") # 构造参数说明。
parser.add_argument("--input", type=Path, default=root / "data/user_behavior_l14.csv") # 默认本地CSV。
parser.add_argument("--output-dir", type=Path, default=root / "outputs") # 默认保存到项目outputs。
args = parser.parse_args()            # 从spark-submit后面的参数中读取值。
input_path = args.input.expanduser().resolve() # 将~和相对路径转为本地绝对路径。
if not input_path.is_file():          # 在启动Spark之前检查文件，便于判断路径错误。
    raise FileNotFoundError(f"找不到CSV：{input_path}；请检查文件已保存到Ubuntu的data目录。") # 不转向HDFS。
output_dir = args.output_dir.expanduser().resolve() # 输出路径同样转为绝对路径。
spark = SparkSession.builder.appName("L14_RDD_Behavior_Lab").getOrCreate() # master由提交命令指定。
sc = spark.sparkContext               # 获取RDD入口。
sc.setLogLevel("WARN")               # 保留警告和错误，降低INFO噪声。
try:                                  # 最后一定调用spark.stop()。
    assert sc.master == "local[2]", "请使用--master 'local[2]'。" # 明确本实验不使用集群服务。
    raw = sc.textFile(input_path.as_uri(), minPartitions=2) # file:///...明确读取Ubuntu本地文件。
    header = raw.first()               # Action：取首行；本课文件必须有指定表头。
    assert header == "event_id,user_id,item_id,behavior", "CSV表头与本课约定不符。" # 避免字段错位。
    data_lines = raw.filter(lambda line: line != header) # Transformation：排除唯一表头。
    parsed = data_lines.map(lambda line: [cell.strip() for cell in line.split(",")]) # 按限定格式拆分并去字段两端空格。
    valid = parsed.filter(is_valid)    # Transformation：只保留字段齐全、非空、行为合法的记录。
    print("[分区] 原始RDD：", raw.getNumPartitions()) # 记录实际分区数，不把建议值当作保证。
    print("[分区] 有效RDD：", valid.getNumPartitions()) # 观察过滤前后实际分区数。
    input_count = data_lines.count()   # Action：原始数据行数，不含表头。
    valid_count = valid.count()        # Action：通过规则的事件行数，不按用户或事件ID去重。
    invalid_count = input_count - valid_count # 被过滤行数，便于定位数据质量问题。
    behavior_pairs = valid.map(lambda row: (row[3], 1)) # 每次行为产生(行为,1)。
    behavior_totals = behavior_pairs.reduceByKey(add) # 按行为聚合；通常形成Shuffle边界。
    print("[分区] 行为聚合RDD：", behavior_totals.getNumPartitions()) # 记录聚合后的实际分区数。
    behavior_counts = dict(sorted(behavior_totals.collect())) # Action：只收集三个小结果并按键排序。
    item_pairs = valid.map(lambda row: (row[2], 1)) # 每次有效事件产生(商品ID,1)。
    item_counts = dict(sorted(item_pairs.reduceByKey(add).collect())) # 按商品累加后按ID稳定排序。
    assert input_count == valid_count + invalid_count # 第一条守恒：原始=有效+无效。
    assert sum(behavior_counts.values()) == valid_count # 第二条守恒：各行为之和=有效事件数。
    assert sum(item_counts.values()) == valid_count # 第三条守恒：各商品之和=有效事件数。
    result = {                        # 组织可独立核验的结果；不把运行环境写进统计JSON。
        "input_data_rows": input_count, # 原始数据行数（不含表头）。
        "valid_rows": valid_count,    # 有效事件行数。
        "invalid_rows": invalid_count, # 过滤掉的行数。
        "behavior_counts": behavior_counts, # 每类行为的事件数；buy不是购买件数。
        "item_counts": item_counts,  # 每个商品的所有有效行为事件数。
    }
    output_dir.mkdir(parents=True, exist_ok=True) # 只新建本项目输出目录，不改系统配置。
    output_file = output_dir / "basic_results.json" # 固定结果文件名，便于提交与比对。
    output_file.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8") # 重跑更新同名结果。
    print("[输入本地URI]", input_path.as_uri()) # 明确没有读取hdfs://路径。
    print(json.dumps(result, ensure_ascii=False, indent=2)) # 同时将小结果显示到终端。
    print("BASIC_CHECK_PASS：三条计数守恒通过。") # 守恒通过仍须手工抽查，不等于教师已评分。
    print("[结果文件]", output_file) # 学生需保留此JSON和本人源码。
finally:                              # 正常结束或报错均执行。
    spark.stop()                      # 结束本程序，释放Spark资源。
