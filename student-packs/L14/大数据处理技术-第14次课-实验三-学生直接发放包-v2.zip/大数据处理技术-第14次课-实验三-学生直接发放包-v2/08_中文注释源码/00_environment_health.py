# -*- coding: utf-8 -*-
"""第14课：真实提交一个小RDD任务，检查Driver与Worker，而非只打印环境变量。
执行位置：VS Code Remote SSH连接的Ubuntu终端；不在Windows本地执行。
命令：/usr/local/spark/bin/spark-submit --master 'local[2]' code/00_environment_health.py
"""
import os                            # 读取当前终端临时设置的环境变量。
import sys                           # 读取Driver实际Python路径和版本。
from pyspark.sql import SparkSession # 只借用会话入口；本课计算仍用RDD。


def inspect_partition(items):        # 此函数在Python Worker中执行。
    import sys                       # 在Worker内读取，而不是沿用Driver输出。
    list(items)                      # 消费该分区的小输入。
    yield (sys.executable, tuple(sys.version_info[:2])) # 返回Worker路径和主次版本。


spark = SparkSession.builder.appName("L14_Environment_Health").getOrCreate() # 启动Spark。
sc = spark.sparkContext              # 取出RDD入口SparkContext。
sc.setLogLevel("WARN")              # 降低普通日志量，不隐藏错误。
try:                                 # 无论成功失败，都在finally释放Spark。
    driver_path = sys.executable      # Driver实际解释器，不是凭空假定/usr/bin/python3。
    driver_version = tuple(sys.version_info[:2]) # 只比较主次版本，例(3, 11)。
    workers = sc.parallelize([1, 2], 2).mapPartitions(inspect_partition).collect() # 真正触发Worker。
    print("[环境] Spark版本：", spark.version) # 应为课堂固定的3.5.9。
    print("[环境] master：", sc.master) # 应为local[2]。
    print("[环境] Java版本：", sc._jvm.java.lang.System.getProperty("java.version")) # 显示实际JVM。
    print("[环境] Driver Python：", driver_path, driver_version) # 显示实际Driver。
    print("[环境] Worker Python：", workers) # 两条记录对应两个小分区，不承诺两个不同进程。
    print("[环境] PYSPARK_DRIVER_PYTHON：", os.environ.get("PYSPARK_DRIVER_PYTHON")) # 查看临时值。
    print("[环境] PYSPARK_PYTHON：", os.environ.get("PYSPARK_PYTHON")) # 查看临时值。
    assert spark.version == "3.5.9", "Spark版本与本课约定不符，请先请教师确认。" # 不自动升级软件。
    assert sc.master == "local[2]", "本实验只使用local[2]，请检查spark-submit命令。" # 不接入YARN。
    assert len(workers) == 2, "健康任务未返回两个分区记录。" # 检查真实任务完整返回。
    assert all(path == driver_path and version == driver_version for path, version in workers), "Driver/Worker不一致，请重新双export。" # 拦截常见冲突。
    print("HEALTH_CHECK_PASS：Spark任务成功，Driver/Worker解释器一致。") # 看见此行才继续实验。
finally:                             # 即使断言失败也清理。
    spark.stop()                     # 只停止本程序创建的Spark会话，不停止系统服务。
