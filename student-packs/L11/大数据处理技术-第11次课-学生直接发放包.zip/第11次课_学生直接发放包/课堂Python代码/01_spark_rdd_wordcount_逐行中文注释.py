# -*- coding: utf-8 -*-
"""
第11次课：第一次运行 Spark 的 RDD WordCount。

课程目的：把第6次课手工写 Java Mapper/Reducer 的经历，与 PySpark 的简洁表达作对比。
运行位置：Ubuntu 虚拟机中的 VS Code 远程终端。
运行方式：/usr/local/spark/bin/spark-submit --master 'local[2]' 01_spark_rdd_wordcount_逐行中文注释.py

说明：local[2] 是“本地模式调用2个计算线程”，不是“两台虚拟机”。
本程序不依赖HDFS/YARN运行，因此第一次学习Spark时容易排查。
"""

from pyspark.sql import SparkSession  # SparkSession 是使用 Spark 的统一入口。

# builder：准备创建SparkSession。
# appName：给这次程序取名字；在Spark的监控页面也能看到。
# getOrCreate：已有会话就复用，没有就创建。
spark = SparkSession.builder.appName("L11-RDD-WordCount").getOrCreate()

# 从SparkSession取出SparkContext。RDD是Spark较早的低层数据抽象。
sc = spark.sparkContext

# 日志过多会影响初学者寻找结果，这里只显示警告及以上信息。
sc.setLogLevel("WARN")

# 定义三行课堂文本，先由学生人工数出每个单词出现次数。
lines = [
    "hello spark",           # 第一行：hello、spark
    "hello hadoop",          # 第二行：hello、hadoop
    "spark makes data easy"  # 第三行：spark、makes、data、easy
]

# parallelize：把普通Python列表交给Spark形成RDD。
# numSlices=2：把数据逻辑上划成2个分区，方便后面讨论并行处理。
rdd = sc.parallelize(lines, numSlices=2)

# flatMap：把每行拆成单词，再把多行单词展平到同一个序列。
# lambda：没有单独起名的简短函数；line.split()按空格拆分。
words = rdd.flatMap(lambda line: line.split())

# map：把每个单词变成(单词, 1)，即(Key, Value)。
# 这一步对应之前MapReduce里Mapper输出的Key-Value思想。
pairs = words.map(lambda word: (word, 1))

# reduceByKey：将相同Key的Value累加，得到每个单词出现的次数。
# a+b表示对一组数做求和。这一步内部可能涉及Shuffle。
counts = pairs.reduceByKey(lambda a, b: a + b)

# collect：把计算结果取回到当前Python程序；也会真正触发Spark作业。
# 因为数据很小，课堂演示可以collect；大数据不能随意collect到一台机器。
result = sorted(counts.collect(), key=lambda item: item[0])

print("========== Spark RDD WordCount ==========")
for word, count in result:
    print(f"{word}\t{count}")  # \t 表示制表符，方便输出整齐。
print("分区数量：", rdd.getNumPartitions())
print("提示：请用自己的话解释flatMap、map、reduceByKey和collect。")

# 最后关闭Spark会话，释放本地计算资源。
spark.stop()
