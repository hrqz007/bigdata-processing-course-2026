# -*- coding: utf-8 -*-
"""
第11次课提高任务：DataFrame初体验。

和RDD WordCount不同，这里有结构化的列名(category、amount、status)。
学生只需看懂“读CSV → 过滤已支付 → 按类别求和”的整体流程。
本课不要求掌握全部DataFrame API，下次课及后续会深入练习。

运行前：请确认终端当前位于此文件所在目录；课堂CSV与Python程序放在同一目录。
运行：/usr/local/spark/bin/spark-submit --master 'local[2]' 02_spark_dataframe_初体验_逐行中文注释.py
"""

from pyspark.sql import SparkSession       # 建立与Spark的连接。
from pyspark.sql.functions import col, sum as spark_sum  # col选择列；sum用于聚合。
from pathlib import Path                # 处理本地文件路径，避免写死用户名。

spark = SparkSession.builder.appName("L11-DataFrame-Preview").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# Path(__file__)：当前.py文件的位置。
# parent：所在文件夹；再拼接CSV文件名，因此不依赖当前终端cd到哪里。
csv_path = str(Path(__file__).resolve().parent / "orders_l11.csv")

# header=True：CSV第一行是列名，而不是业务数据。
# inferSchema=True：让Spark尝试推断金额列是数字（小样例便于演示）。
df = spark.read.csv(csv_path, header=True, inferSchema=True)

print("========== 1. 原始数据结构 ==========")
df.printSchema()                              # 打印列名及数据类型。
print("========== 2. 原始数据（最多12条） ==========")
df.show(12, truncate=False)                  # 显示数据，truncate=False避免文字被截断。

# filter：只保留已支付订单；不同于只计数，真实业务常有筛选需求。
paid = df.filter(col("status") == "paid")

# groupBy：按商品类别分组。
# agg：聚合；给每类的amount金额求和。
result = paid.groupBy("category").agg(spark_sum("amount").alias("paid_amount"))

print("========== 3. 已支付订单按类别汇总 ==========")
result.orderBy("category").show(truncate=False)

# 本课只看懂思路：读取 → 过滤 → 分组 → 聚合 → 展示。
spark.stop()
