# -*- coding: utf-8 -*-
"""
第11次课C级扩展：让Spark直接读取HDFS中的文本文件。
只有在HDFS已经启动且前面两个程序正常后才尝试。

教师事先准备：
    start-dfs.sh
    hdfs dfs -mkdir -p /user/$USER/bigdata/lesson11/input
    hdfs dfs -put -f words_l11.txt /user/$USER/bigdata/lesson11/input/

命令示例：
  HADOOP_CONF_DIR=/usr/local/hadoop/etc/hadoop /usr/local/spark/bin/spark-submit \
     --master 'local[2]' 03_spark_hdfs_可选扩展_逐行中文注释.py
"""
import os
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("L11-HDFS-Read").getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN")

# os.environ['USER']：当前Ubuntu用户名，通常是hadoop。
user = os.environ.get("USER", "hadoop")

# 使用完整HDFS URI，明确告诉Spark不要读本地Linux文件系统。
# localhost:9000来自当前课程的Hadoop fs.defaultFS配置，若实际不同应先查看配置。
hdfs_uri = f"hdfs://localhost:9000/user/{user}/bigdata/lesson11/input/words_l11.txt"

print("Spark即将读取的HDFS路径：", hdfs_uri)

# textFile：通过HDFS客户端读取文件，生成RDD。
lines = sc.textFile(hdfs_uri)

# count：真正触发计算并得到文件总行数。
print("HDFS中的行数：", lines.count())

# take(3)：只取前3条；比collect全部数据安全。
print("前3行：", lines.take(3))

spark.stop()
