第12次课学生直接发放包｜RDD补强 + HDFS双表Join

今天我们不是重新上4讲PySpark基础；你将第一次把HDFS中的订单表与商品表关联，观察无法匹配的商品编号，并把结果保存回HDFS。前15分钟先看RDD最小例子。

推荐使用顺序：
1. 打开03_学生VSCode保姆式操作手册.docx（知道每一步做什么）。
2. 先读08_术语与参数速查表.docx（看懂status、product_id、价格等业务字段）。
3. 在Windows解压学生ZIP；将code/和data/这两个目录复制到远程Ubuntu的~/bigdata_course/spark/lesson12_case。
4. 打开VS Code远程终端，按07_分步复制命令/00—06顺序逐段复制。
5. 先手算预测A结果再运行，记录runA；若课堂有时间做B，绝不覆盖runA。
6. 04_学生练习与验收单.docx记录个人实验输出。

本包没有一键.sh文件。不要因为看见某条命令就整份全复制：每阶段观察结果再继续。

已知参考：A已支付12条，匹配11条，不匹配1条，按标价估算金额22155元；o008/p999是刻意保留的异常订单。

如Spark报错先检查Driver/Worker Python路径，如HDFS拒绝连接先查jps，不格式化NameNode。
