package com.dblab.bigdata;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * 第8次课示例：电商用户行为计数（YARN + Shuffle + 自定义Partitioner）。
 *
 * 数据字段：
 * user_id,item_id,behavior,event_time
 *
 * behavior 的含义：
 * pv   = Page View，浏览商品
 * cart = Add to Cart，加入购物车
 * fav  = Favorite，收藏商品
 * buy  = Buy，购买商品
 *
 * 本程序统计每种行为出现多少次，并使用两个 Reducer 展示“分区”效果。
 */
public class BehaviorCountYarn {

    /**
     * Mapper：读取CSV的一行，把 behavior 字段作为Key，数字1作为Value。
     *
     * 例如：
     * u001,i101,pv,2026-09-22 10:01:00
     *      ↓ Mapper
     * <pv, 1>
     */
    public static class BehaviorMapper
            extends Mapper<LongWritable, Text, Text, IntWritable> {

        // 常量1：每读到一条行为记录，就给对应行为贡献一次计数。
        private static final IntWritable ONE = new IntWritable(1);

        // 重复使用Text对象，减少频繁创建对象的开销。
        private final Text behaviorKey = new Text();

        @Override
        protected void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {

            // 把Hadoop传入的一整行文本转换成普通Java字符串。
            String line = value.toString().trim();

            // 空行不处理。
            if (line.isEmpty()) {
                return;
            }

            // 跳过CSV表头，否则 behavior 会被误当成一种用户行为。
            if (line.startsWith("user_id,")) {
                return;
            }

            // 按英文逗号切分CSV。limit=-1表示即使末尾字段为空也保留。
            String[] fields = line.split(",", -1);

            // 我们的样例数据应该有4列。
            // 如果少于4列，说明是坏记录，本例先跳过。
            if (fields.length < 4) {
                return;
            }

            // 第3列（下标2）就是 behavior，例如 pv、buy、cart、fav。
            String behavior = fields[2].trim();

            // behavior为空时不统计。
            if (behavior.isEmpty()) {
                return;
            }

            behaviorKey.set(behavior);

            // Mapper输出中间Key-Value：<behavior, 1>
            context.write(behaviorKey, ONE);
        }
    }

    /**
     * Reducer：把同一个 behavior 对应的一组1相加。
     *
     * 例如Shuffle后：
     * pv -> [1,1,1,1,1,1]
     * Reducer输出：
     * pv -> 6
     */
    public static class SumReducer
            extends Reducer<Text, IntWritable, Text, IntWritable> {

        private final IntWritable result = new IntWritable();

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;

            // values中装的是同一个key的所有局部计数。
            for (IntWritable value : values) {
                sum += value.get();
            }

            result.set(sum);
            context.write(key, result);
        }
    }

    /**
     * 自定义Partitioner：决定“某个中间Key应该去哪个Reducer”。
     *
     * 本课故意不用默认HashPartitioner，是为了让学生看得见“分区”的结果：
     * Reducer 0：pv、cart
     * Reducer 1：buy、fav
     *
     * 注意：真实项目中一般根据业务和数据分布设计分区，不能随便硬编码。
     */
    public static class BehaviorPartitioner
            extends Partitioner<Text, IntWritable> {

        @Override
        public int getPartition(Text key, IntWritable value, int numPartitions) {

            // 如果没有Reducer（numPartitions=0），这里理论上不会被正常调用。
            // 防御性写法返回0，避免除0或越界。
            if (numPartitions <= 1) {
                return 0;
            }

            String behavior = key.toString();

            // 把浏览和加购物车送到第0号Reducer。
            if ("pv".equals(behavior) || "cart".equals(behavior)) {
                return 0;
            }

            // 购买、收藏以及其他未知行为送到第1号Reducer。
            return 1;
        }
    }

    public static void main(String[] args) throws Exception {

        // 必须提供两个命令行参数：HDFS输入目录、HDFS输出目录。
        if (args.length != 2) {
            System.err.println("用法: BehaviorCountYarn <input> <output>");
            System.exit(2);
        }

        // 读取Hadoop配置。第8课会让mapreduce.framework.name=yarn。
        Configuration conf = new Configuration();

        // 创建并命名一个MapReduce Job。
        Job job = Job.getInstance(conf, "behavior-count-yarn");

        // 告诉Hadoop：主类位于哪个JAR中。
        job.setJarByClass(BehaviorCountYarn.class);

        // 指定Mapper。
        job.setMapperClass(BehaviorMapper.class);

        // Combiner是可选的“Map端局部聚合”。
        // 求和满足结合律/交换律，所以这里可以安全地复用SumReducer做Combiner。
        // 它的作用是尽量减少Shuffle需要传输的中间数据。
        job.setCombinerClass(SumReducer.class);

        // 指定自定义Partitioner，明确演示两个Reducer的分工。
        job.setPartitionerClass(BehaviorPartitioner.class);

        // 指定Reducer。
        job.setReducerClass(SumReducer.class);

        // 使用2个Reducer，这样最终会产生两个part-r文件。
        job.setNumReduceTasks(2);

        // Mapper最终中间Key/Value的类型。
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        // Reducer最终输出Key/Value的类型。
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // 设置HDFS输入路径。
        FileInputFormat.addInputPath(job, new Path(args[0]));

        // 设置HDFS输出路径。
        // 注意：Hadoop要求输出目录在任务启动前不能已经存在。
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        // 提交任务并等待结束。
        // true表示在终端持续打印进度和Counters。
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
