#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# 第8次课：安全配置单机YARN
# 仅在教师确认“当前YARN尚未配置”后执行。
# 脚本会：
# 1) 自动备份mapred-site.xml和yarn-site.xml；
# 2) 只新增/更新本课需要的4个property；
# 3) 不修改core-site.xml和hdfs-site.xml；
# 4) 不格式化HDFS，不删除数据。
# ============================================================

HADOOP_HOME="${HADOOP_HOME:-/usr/local/hadoop}"
CONF_DIR="$HADOOP_HOME/etc/hadoop"
MAPRED="$CONF_DIR/mapred-site.xml"
YARN="$CONF_DIR/yarn-site.xml"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [[ ! -d "$CONF_DIR" ]]; then
  echo "[ERROR] 找不到Hadoop配置目录：$CONF_DIR"
  exit 1
fi

# 如果mapred-site.xml不存在，但模板存在，则先复制模板。
if [[ ! -f "$MAPRED" && -f "$CONF_DIR/mapred-site.xml.template" ]]; then
  cp "$CONF_DIR/mapred-site.xml.template" "$MAPRED"
fi

# 如果仍不存在，就创建最小configuration骨架。
if [[ ! -f "$MAPRED" ]]; then
  printf '%s\n' '<?xml version="1.0"?>' '<configuration>' '</configuration>' > "$MAPRED"
fi

if [[ ! -f "$YARN" ]]; then
  printf '%s\n' '<?xml version="1.0"?>' '<configuration>' '</configuration>' > "$YARN"
fi

# 修改前先备份。
cp "$MAPRED" "$MAPRED.bak_lesson8_$STAMP"
cp "$YARN" "$YARN.bak_lesson8_$STAMP"

echo "[OK] 已备份："
echo "  $MAPRED.bak_lesson8_$STAMP"
echo "  $YARN.bak_lesson8_$STAMP"

# 使用Python标准库安全修改XML，而不是用sed粗暴替换。
python3 - "$MAPRED" "$YARN" <<'PY'
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

mapred = Path(sys.argv[1])
yarn = Path(sys.argv[2])

def ensure_root(path: Path):
    try:
        tree = ET.parse(path)
        root = tree.getroot()
        if root.tag != 'configuration':
            raise ValueError(f'{path} 根节点不是configuration')
        return tree, root
    except ET.ParseError as e:
        raise SystemExit(f'[ERROR] {path} XML格式损坏：{e}')

def set_property(root, name, value):
    found = None
    for prop in root.findall('property'):
        name_el = prop.find('name')
        if name_el is not None and (name_el.text or '').strip() == name:
            found = prop
            break
    if found is None:
        found = ET.SubElement(root, 'property')
        ET.SubElement(found, 'name').text = name
        ET.SubElement(found, 'value').text = value
    else:
        value_el = found.find('value')
        if value_el is None:
            value_el = ET.SubElement(found, 'value')
        value_el.text = value

map_tree, map_root = ensure_root(mapred)
set_property(map_root, 'mapreduce.framework.name', 'yarn')
set_property(
    map_root,
    'mapreduce.application.classpath',
    '$HADOOP_MAPRED_HOME/share/hadoop/mapreduce/*:$HADOOP_MAPRED_HOME/share/hadoop/mapreduce/lib/*'
)
ET.indent(map_tree, space='  ')
map_tree.write(mapred, encoding='unicode', xml_declaration=True)

yarn_tree, yarn_root = ensure_root(yarn)
set_property(yarn_root, 'yarn.nodemanager.aux-services', 'mapreduce_shuffle')
set_property(
    yarn_root,
    'yarn.nodemanager.env-whitelist',
    'JAVA_HOME,HADOOP_COMMON_HOME,HADOOP_HDFS_HOME,HADOOP_CONF_DIR,'
    'CLASSPATH_PREPEND_DISTCACHE,HADOOP_YARN_HOME,HADOOP_HOME,PATH,LANG,TZ,HADOOP_MAPRED_HOME'
)
ET.indent(yarn_tree, space='  ')
yarn_tree.write(yarn, encoding='unicode', xml_declaration=True)
PY

echo "[OK] YARN所需配置已写入。"
echo "[NEXT] 请重新运行02只读检查，然后执行04启动YARN。"
