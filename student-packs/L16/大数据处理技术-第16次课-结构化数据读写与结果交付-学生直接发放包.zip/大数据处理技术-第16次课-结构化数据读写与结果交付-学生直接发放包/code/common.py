# -*- coding: utf-8 -*-
"""L16公共定义：每个阶段启动新会话，显式描述每列含义与类型。"""
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType

# CSV只有文本，不会替我们保存列类型；数量、价格在读取时明确指定整数。
# True表示读取后允许nullable元数据；是否实际缺值仍由后面的质量检查把关。
ORDER_SCHEMA = StructType([
    StructField('order_id', StringType(), True),  # 订单编号：字符串，例如o001。
    StructField('user_id', StringType(), True),  # 用户编号：字符串。
    StructField('product_id', StringType(), True),  # 商品编号：字符串，供Join使用。
    StructField('quantity', IntegerType(), True),  # 购买数量：整数，不是字符串。
    StructField('status', StringType(), True),  # 订单状态：paid或cancelled。
])
PRODUCT_SCHEMA = StructType([
    StructField('product_id', StringType(), True),  # 商品编号：唯一键。
    StructField('product_name', StringType(), True),  # 商品名称：字符串。
    StructField('category', StringType(), True),  # 类别：本课按此列分区保存。
    StructField('unit_price_yuan', IntegerType(), True),  # 单价：整数元，本例没有小数价格。
])
SUMMARY_SCHEMA = StructType([StructField('category', StringType(), True),
    StructField('order_count', LongType(), True), StructField('quantity_sum', LongType(), True),
    StructField('estimated_amount_yuan', LongType(), True)])


def require_hdfs(spark, path):
    """拒绝把file:///冒充HDFS；hdfs:///由机房core-site.xml解析主机和端口。"""
    if not path.startswith('hdfs://'):
        raise ValueError('必须使用hdfs://路径，本课不允许用本地目录替代HDFS')
    p = spark._jvm.org.apache.hadoop.fs.Path(path)
    fs = p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration())
    if fs.getUri().getScheme() != 'hdfs':
        raise ValueError('实际文件系统不是HDFS')
    return fs, p


def read_inputs(spark, root):
    require_hdfs(spark, root)
    def read(name, schema):
        # FAILFAST拒绝类型解析失败；enforceSchema=false还会核对表头顺序。
        return (spark.read.option('header', True).option('mode', 'FAILFAST')
                .option('enforceSchema', False).schema(schema).csv(root + '/' + name))
    orders = read('orders_l12_A.csv', ORDER_SCHEMA)
    products = read('products_l12.csv', PRODUCT_SCHEMA)
    # 显式schema不能代替数据质量检查。required列中的空值也要检查。
    for label, df in [('orders', orders), ('products', products)]:
        bad = F.lit(False)
        for name in df.columns:
            bad = bad | F.col(name).isNull()
        assert df.filter(bad).count() == 0, label + '出现空值/解析失败'
    assert orders.count() == 14, '课堂数据订单应为14条'
    assert products.count() == products.select('product_id').distinct().count(), '商品主键重复，会放大Join结果'
    assert products.count() == 6, '课堂商品表应为6条'
    assert orders.filter(F.col('quantity') <= 0).count() == 0
    assert products.filter(F.col('unit_price_yuan') < 0).count() == 0
    return orders, products


def business_result(orders, products):
    # 本段复用L15：先paid，再Join；未匹配p999不能冒充0元订单。
    paid = orders.filter(F.col('status') == 'paid')
    unmatched = paid.join(products, 'product_id', 'left').filter(F.col('product_name').isNull()).select(*paid.columns)
    detail = (paid.join(products, 'product_id', 'inner')
        .withColumn('estimated_amount_yuan', F.col('quantity').cast('long') * F.col('unit_price_yuan'))
        .select('order_id', 'user_id', 'product_id', 'quantity', 'status', 'product_name',
                'unit_price_yuan', 'estimated_amount_yuan', 'category'))
    summary = detail.groupBy('category').agg(
        F.count('*').alias('order_count'), F.sum('quantity').alias('quantity_sum'),
        F.sum('estimated_amount_yuan').alias('estimated_amount_yuan'))
    assert paid.count() == 12 and unmatched.count() == 1 and detail.count() == 11
    assert detail.agg(F.sum('estimated_amount_yuan')).first()[0] == 22155
    return paid, unmatched, detail, summary


def assert_same(expected, actual):
    # 比较字段名/类型而非nullable；文件回读nullable可能变化，行序不保证。
    left = {f.name: f.dataType.simpleString() for f in expected.schema.fields}
    right = {f.name: f.dataType.simpleString() for f in actual.schema.fields}
    assert left == right, ('Schema不一致', left, right)
    actual = actual.select(*expected.columns)
    assert expected.count() == actual.count(), '记录数不同'
    # 仅14条的课堂小样本可收集成多重集合，比较每条内容及重复次数。
    # 这是提供好的教师核验工具，不要求学生实现；大数据不能直接collect到Driver。
    from collections import Counter
    assert Counter(tuple(r) for r in expected.collect()) == Counter(tuple(r) for r in actual.collect()), '内容不一致'
