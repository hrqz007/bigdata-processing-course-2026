# -*- coding: utf-8 -*-
"""第16课分阶段程序。每次只运行指定stage，所有输入和结果均在HDFS。"""
import argparse
from pyspark.sql import SparkSession, functions as F
from common import read_inputs, business_result, require_hdfs, assert_same, SUMMARY_SCHEMA

parser = argparse.ArgumentParser()
parser.add_argument('--stage', required=True, choices=['schema', 'join', 'write-csv', 'write-parquet', 'partition', 'verify'])
parser.add_argument('--input', required=True, help='HDFS输入目录')
parser.add_argument('--output', help='HDFS本次运行根目录，如.../output/runA')
args = parser.parse_args()
if args.stage in ['write-csv', 'write-parquet', 'partition', 'verify'] and not args.output:
    parser.error('写出或verify需要--output')
spark = SparkSession.builder.appName('L16_' + args.stage).getOrCreate()
spark.sparkContext.setLogLevel('WARN')
spark.conf.set('spark.sql.shuffle.partitions', '2')  # 小样本使用2个shuffle分区，不是启动两台机器。
try:
    orders, products = read_inputs(spark, args.input.rstrip('/'))
    if args.stage == 'schema':
        orders.printSchema()
        products.printSchema()
        orders.show(20, truncate=False)
        print('INPUT_COUNTS orders=14 products=6')
    else:
        paid, unmatched, detail, summary = business_result(orders, products)
        if args.stage == 'join':
            unmatched.show(truncate=False)
            summary.orderBy('category').show(truncate=False)
            print('BUSINESS_COUNTS paid=12 matched=11 unmatched=1 estimated_amount_yuan=22155')
        elif args.stage in ['write-csv', 'write-parquet', 'partition']:
            root = args.output.rstrip('/')
            require_hdfs(spark, root)
            # 每类结果独立提交；errorifexists拒绝覆盖该子目录，保留runA后可用runB。
            if args.stage == 'write-csv':
                summary.write.mode('errorifexists').option('header', True).csv(root + '/summary_csv')
            elif args.stage == 'write-parquet':
                summary.write.mode('errorifexists').parquet(root + '/summary_parquet')
            else:
                detail.write.mode('errorifexists').partitionBy('category').parquet(root + '/detail_by_category')
            print('WRITE_PASS', args.stage, root)
        elif args.stage == 'verify':
            root = args.output.rstrip('/')
            require_hdfs(spark, root)
            # 首次不指定schema读取CSV，展示“数值列也成了string”。
            csv_text = spark.read.option('header', True).csv(root + '/summary_csv')
            csv_text.printSchema()
            assert all(t == 'string' for _, t in csv_text.dtypes)
            csv_typed = (spark.read.option('header', True).option('mode', 'FAILFAST')
                .option('enforceSchema', False).schema(SUMMARY_SCHEMA).csv(root + '/summary_csv'))
            parquet = spark.read.parquet(root + '/summary_parquet')
            # 必须从分区根目录读；Spark据category=xxx目录恢复分区列。
            reread_detail = spark.read.parquet(root + '/detail_by_category')
            parquet.printSchema()
            reread_detail.printSchema()
            summary.cache()  # 小样本复用结果，避免三轮核验重复计算Join。
            detail.cache()
            assert_same(summary, csv_typed)
            print("CSV_CONTENT_PASS", flush=True)
            assert_same(summary, parquet)
            print("PARQUET_CONTENT_PASS", flush=True)
            assert_same(detail, reread_detail)
            print("PARTITION_CONTENT_PASS", flush=True)
            assert reread_detail.agg(F.sum('estimated_amount_yuan')).first()[0] == 22155
            print('VERIFY_PASS summary_rows=6 detail_rows=11 estimated_amount_yuan=22155')
    print('STAGE_PASS', args.stage)
finally:
    spark.stop()  # 仅停止本应用，不关闭机房HDFS。
