#!/usr/bin/env bash
# ============================================================
# 目的：课程结束前正确停止 HDFS，养成规范的服务管理习惯
# ============================================================

# stop-dfs.sh 会停止 NameNode、DataNode、SecondaryNameNode。
stop-dfs.sh

# 再用 jps 验证。正常情况下，不应再看到 NameNode/DataNode/SecondaryNameNode。
echo "========== 停止后的 Java 进程 =========="
jps
