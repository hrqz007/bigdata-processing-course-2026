#!/usr/bin/env bash
# ============================================================
# 目的：确认今天编译 WordCount 所需的 Java/Hadoop 工具都存在
# ============================================================

# java -version：检查 Java 运行环境。当前课程基线是 JDK 1.8。
echo "========== Java 运行环境 =========="
java -version

# javac -version：检查 Java 编译器。没有 javac 就不能把 .java 编译为 .class。
echo "========== Java 编译器 =========="
javac -version

# command -v jar：告诉我们 jar 命令实际位于哪里。
# jar 用来把多个 .class 文件打包成一个 .jar 文件。
echo "========== jar 工具 =========="
command -v jar

# hadoop version：确认 Hadoop 版本。本课程统一使用 Hadoop 3.3.5。
echo "========== Hadoop 版本 =========="
hadoop version | head -n 1

# hadoop classpath --glob：输出编译 Hadoop 程序所需的依赖 JAR 路径。
# 这里只显示前 200 个字符，避免终端输出太长。
echo "========== Hadoop 编译 classpath（前200字符） =========="
hadoop classpath --glob | head -c 200
echo
