package com.dblab.bigdata;

// Hadoop MapReduce 的核心类：Mapper、Reducer、Job 等都来自这些包。
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * WordCount：统计输入文本中每个单词出现的次数。
 *
 * 输入示例：
 *   hello big data
 *   hello hadoop
 *   big data hadoop
 *
 * 期望输出：
 *   big     2
 *   data    2
 *   hadoop  2
 *   hello   2
 */
public class WordCount {

    /**
     * Mapper 的四个泛型依次表示：
     * 1. 输入 key 的类型：Object（文本文件中通常是行偏移量）
     * 2. 输入 value 的类型：Text（当前这一行文本）
     * 3. 输出 key 的类型：Text（单词）
     * 4. 输出 value 的类型：IntWritable（数字1）
     */
    public static class TokenizerMapper
            extends Mapper<Object, Text, Text, IntWritable> {

        // 每遇到一个单词，就输出一次数字 1。
        private static final IntWritable ONE = new IntWritable(1);

        // Text 是 Hadoop 自己的字符串类型。
        private final Text word = new Text();

        @Override
        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {

            // 把当前一行文本按空白字符拆成一个个单词。
            StringTokenizer tokenizer = new StringTokenizer(value.toString());

            while (tokenizer.hasMoreTokens()) {
                // 取出下一个单词。
                word.set(tokenizer.nextToken());

                // Mapper 输出中间键值对，例如：(hello, 1)。
                context.write(word, ONE);
            }
        }
    }

    /**
     * Reducer 接收相同单词对应的一组 1，然后求和。
     * 例如 hello -> [1, 1]，最后输出 hello -> 2。
     */
    public static class IntSumReducer
            extends Reducer<Text, IntWritable, Text, IntWritable> {

        private final IntWritable result = new IntWritable();

        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;

            // 把同一个单词对应的所有 1 加起来。
            for (IntWritable value : values) {
                sum += value.get();
            }

            result.set(sum);

            // 输出最终结果，例如：(hello, 2)。
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {
        // 本程序需要两个参数：输入路径、输出路径。
        if (args.length != 2) {
            System.err.println("用法: WordCount <输入路径> <输出路径>");
            System.exit(2);
        }

        // 读取 Hadoop 当前配置。
        Configuration conf = new Configuration();

        // 创建一个 MapReduce 作业，并给它起名 word-count。
        Job job = Job.getInstance(conf, "word-count");

        // 告诉 Hadoop：主类是 WordCount。
        job.setJarByClass(WordCount.class);

        // 指定 Mapper 和 Reducer。
        job.setMapperClass(TokenizerMapper.class);
        job.setReducerClass(IntSumReducer.class);

        // 最终输出的 key 是 Text，value 是 IntWritable。
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // args[0]：HDFS 输入目录；args[1]：HDFS 输出目录。
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        // 提交作业并等待执行结束。成功返回 true，失败返回 false。
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
