#!/usr/bin/env bash
# ============================================================
# 目的：验证 WordCount 是否成功，并读懂关键结果
# ============================================================
OUTPUT="/user/$USER/bigdata/lesson6/output"

# 1) 查看输出目录。
# 正常会看到：
#   _SUCCESS       —— 0 字节成功标志文件
#   part-r-00000   —— Reducer 的实际输出文件
echo "========== 1. 输出目录 =========="
hdfs dfs -ls "$OUTPUT"

# 2) 查看真正的统计结果。
echo "========== 2. WordCount 结果 =========="
hdfs dfs -cat "$OUTPUT/part-r-00000"

# 对本课输入，期望结果是：
# big     2
# data    2
# hadoop  2
# hello   2

# 3) _SUCCESS 没有正文，存在本身就表示作业成功完成。
echo "========== 3. 检查 _SUCCESS 是否存在 =========="
hdfs dfs -test -e "$OUTPUT/_SUCCESS" && echo "_SUCCESS 存在：作业成功标志正常" || echo "未找到 _SUCCESS"
