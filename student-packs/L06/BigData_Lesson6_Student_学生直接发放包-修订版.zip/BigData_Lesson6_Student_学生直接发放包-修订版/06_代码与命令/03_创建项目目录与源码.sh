#!/usr/bin/env bash
# ============================================================
# 目的：创建第6次课 WordCount 项目目录，并放入带注释的 Java 源文件
# ============================================================

# 进入课程统一工作目录。
mkdir -p "$HOME/bigdata_course/mapreduce/wordcount"
cd "$HOME/bigdata_course/mapreduce/wordcount" || exit 1

# 创建符合 Java package com.dblab.bigdata 的源码目录层级。
mkdir -p src/com/dblab/bigdata

# 提示：WordCount.java 已随课程资料包提供。
# 教师/学生可以把资料包中的 WordCount.java 复制到：
#   ~/bigdata_course/mapreduce/wordcount/src/com/dblab/bigdata/WordCount.java

echo "项目目录：$(pwd)"
echo "请确认源码存在："
ls -l src/com/dblab/bigdata/WordCount.java
