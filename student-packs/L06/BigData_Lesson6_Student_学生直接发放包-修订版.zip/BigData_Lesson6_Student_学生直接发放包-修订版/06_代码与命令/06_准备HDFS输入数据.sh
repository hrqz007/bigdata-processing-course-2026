#!/usr/bin/env bash
# ============================================================
# 目的：创建本地输入文本，再上传到 HDFS
# ============================================================
set -e
cd "$HOME/bigdata_course/mapreduce/wordcount" || exit 1

# INPUT/OUTPUT 是两个 Shell 变量，保存 HDFS 输入/输出路径。
INPUT="/user/$USER/bigdata/lesson6/input"
OUTPUT="/user/$USER/bigdata/lesson6/output"

# 创建本地 data 目录。
mkdir -p data

# cat <<'EOF' 是 Here Document：把下面3行文本一次写入 data/input.txt。
cat > data/input.txt <<'EOF'
hello big data
hello hadoop
big data hadoop
EOF

# 先在 Linux 本地查看输入文件。
echo "========== 本地输入 =========="
cat data/input.txt

# 在 HDFS 中创建输入目录。
hdfs dfs -mkdir -p "$INPUT"

# -put -f：把本地文件上传到 HDFS；-f 表示同名文件存在时覆盖。
hdfs dfs -put -f data/input.txt "$INPUT/"

# 查看 HDFS 输入目录和实际内容。
echo "========== HDFS 输入目录 =========="
hdfs dfs -ls "$INPUT"

echo "========== HDFS 输入内容 =========="
hdfs dfs -cat "$INPUT/input.txt"

# 输出路径必须在作业开始前不存在。
# 这里只删除本课程固定 OUTPUT 路径，避免误删其他数据。
hdfs dfs -rm -r -f "$OUTPUT" 2>/dev/null || true

echo "输入已准备完毕。"
