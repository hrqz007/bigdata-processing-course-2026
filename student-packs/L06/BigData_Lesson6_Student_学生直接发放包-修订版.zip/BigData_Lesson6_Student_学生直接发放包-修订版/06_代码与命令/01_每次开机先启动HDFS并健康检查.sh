#!/usr/bin/env bash
# ============================================================
# 第6次课固定开场：启动 HDFS 并检查是否健康
# 适用环境：Ubuntu 22.04 + Hadoop 3.3.5
# ============================================================

# [目的] 每次虚拟机重新开机后，HDFS 服务默认没有运行。
#        如果直接执行 hdfs dfs ...，很可能出现 localhost:9000 Connection refused。

echo "========== 1. 先看当前 Java 进程 =========="
jps

# [目的] 启动 NameNode、DataNode、SecondaryNameNode。
# [说明] start-dfs.sh 位于 $HADOOP_HOME/sbin；我们已经把 sbin 加入 PATH。
echo "========== 2. 启动 HDFS =========="
start-dfs.sh

# 给守护进程几秒钟启动时间。
sleep 3

# [目的] 验证 HDFS 三个核心进程是否真的起来了。
# [正常结果] 通常应该能看到 NameNode、DataNode、SecondaryNameNode、Jps。
echo "========== 3. 再次检查 jps =========="
jps

# [目的] 检查 NameNode 是否能看到 DataNode。
# [正常结果] 我们的单机伪分布式环境应出现 Live datanodes (1)。
echo "========== 4. 查看 HDFS 状态 =========="
hdfs dfsadmin -report | sed -n '1,45p'

# [目的] 查看安全模式。HDFS 刚启动时短暂 ON 是正常现象；持续 ON 才需要排查。
echo "========== 5. 查看 Safe Mode =========="
hdfs dfsadmin -safemode get

# [目的] 确认客户端要连接的 NameNode 地址。
# [本机通常结果] hdfs://localhost:9000
echo "========== 6. 查看默认 HDFS 地址 =========="
hdfs getconf -confKey fs.defaultFS
