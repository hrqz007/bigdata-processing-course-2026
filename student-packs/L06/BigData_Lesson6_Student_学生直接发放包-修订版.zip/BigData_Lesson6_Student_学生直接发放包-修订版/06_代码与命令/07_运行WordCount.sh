#!/usr/bin/env bash
# ============================================================
# 目的：提交 WordCount 作业
# ============================================================
set -e
cd "$HOME/bigdata_course/mapreduce/wordcount" || exit 1

INPUT="/user/$USER/bigdata/lesson6/input"
OUTPUT="/user/$USER/bigdata/lesson6/output"

# hadoop jar：运行一个 Hadoop JAR 程序。
# wordcount.jar：刚才编译打包得到的 JAR。
# com.dblab.bigdata.WordCount：包含 main() 的完整类名。
# "$INPUT"：程序 args[0]，HDFS 输入目录。
# "$OUTPUT"：程序 args[1]，HDFS 输出目录。
hadoop jar wordcount.jar \
  com.dblab.bigdata.WordCount \
  "$INPUT" \
  "$OUTPUT"

# 正常结束时，日志中应看到 map 100% reduce 100% 和 completed successfully。
