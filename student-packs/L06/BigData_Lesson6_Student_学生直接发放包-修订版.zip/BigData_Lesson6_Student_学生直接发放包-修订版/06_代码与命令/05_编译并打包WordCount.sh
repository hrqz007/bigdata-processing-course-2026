#!/usr/bin/env bash
# ============================================================
# 目的：把 WordCount.java 编译为 .class，再打包为 wordcount.jar
# ============================================================
set -e
cd "$HOME/bigdata_course/mapreduce/wordcount" || exit 1

# 清理上一次编译结果，避免旧 class 文件干扰。
rm -rf build wordcount.jar

# build 用来存放编译得到的 .class 文件。
mkdir -p build

# javac：Java 编译器。
# -encoding UTF-8：源代码里有中文注释，明确使用 UTF-8 编码。
# -classpath "$(hadoop classpath --glob)"：把 Hadoop 依赖 JAR 加入编译搜索路径。
# -d build：把编译后的 .class 文件放入 build 目录。
# 最后一行是要编译的 Java 源文件。
javac -encoding UTF-8 \
  -classpath "$(hadoop classpath --glob)" \
  -d build \
  src/com/dblab/bigdata/WordCount.java

# 查看究竟生成了哪些 class 文件。
echo "========== 编译生成的 class 文件 =========="
find build -type f | sort

# jar -cvf：创建一个 JAR 包。
# wordcount.jar：输出文件名。
# -C build .：先切换到 build，再把其中所有 class 文件打进 JAR。
jar -cvf wordcount.jar -C build .

# 查看 JAR 大小和内部文件。
echo "========== JAR 文件 =========="
ls -lh wordcount.jar

echo "========== JAR 内部内容 =========="
jar -tf wordcount.jar
