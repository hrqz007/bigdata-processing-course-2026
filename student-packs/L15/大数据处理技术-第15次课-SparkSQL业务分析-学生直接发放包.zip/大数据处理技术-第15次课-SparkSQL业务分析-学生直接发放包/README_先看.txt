第15次课 Spark SQL业务分析
学生直接发放包。教师参考答案与测试结果不在本包内。

怎么开始
只按03_学生保姆式操作手册.docx操作，在04_课堂学习单_学生版.docx记录预测、实际结果和解释。
本课100分钟普通教学课，不另写正式实验报告。
目标是系统整理SQL查询、临时视图、分组和关联，并核对SQL与DataFrame的业务口径与完整结果。
延续前课真实学过的DataFrame/SQL/Join，不重复安装；第16课再系统讲存储格式、HDFS写读与回读核验。

学生远程项目目录
~/bigdata_course/spark/lesson15_sql
把code中的3个.py放到远程code目录；把data中的2个.csv放到远程data目录。
每次重新开终端先统一Driver/Worker的Python，再运行00_environment_health.py。
本课只需local[2]，无需启动HDFS、YARN、Hive、MySQL或Spark独立集群服务。
禁止格式化NameNode，禁止反复改.bashrc，禁止删除前课结果。

四个阶段
01_sql_basics.py --step select
01_sql_basics.py --step group
02_sql_join_compare.py --step join
02_sql_join_compare.py --step summary
上面是脚本及参数简表，不是完整终端命令。完整命令看手册和07_逐段复制命令，逐段阅读执行，不运行黑箱.sh。
每次spark-submit都会新建应用，临时视图由该脚本在同一会话重新注册。
基线证据自动留在outputs，不是下一课的大规模结果保存任务。
同一阶段重跑会更新对应JSON；练习A1另存outputs/a1，选做A2另存outputs/a2。

材料分工
01 PPT适合投屏；PDF便携阅读版内有所有同名便携副本。
03是唯一操作主线，04是填写用学习单，06是术语与短技术史。
code是逐行中文注释源码；data是沿用前课的模拟订单与商品数据；数据字典.json解释字段。
教师包另有02详细原理教程、05参考答案、10预检排错、11逐页讲稿和独立验证证据。

运行验证边界
已在云端隔离环境真实运行Spark3.5.9和JDK8系列，具体系统、Python、JDK更新号与日志见教师包验证记录。
云端通过不等于Ubuntu22.04/JDK8u371教师VM或全班已验收；开课前仍须真实VM健康检查和四阶段预演。
本课金额是已支付且匹配商品记录的商品标价估算，不是实际营业收入。

版本 2026-11-04 第15课初版
原有第13、14课及历史文件未覆盖。本次未自动修改GitHub、议事厅或教学大纲。
