《大数据处理技术》第一周第3次课 学生文件包

【使用前】
1. 把整个 BigData_Lesson3_Student 文件夹放到 Ubuntu 桌面（Desktop）。
2. 今天不要安装 Hadoop，不要执行 hdfs namenode -format，不要自己修改 ~/.bashrc。
3. 按 01 → 03 → 04 → 05 → 06 的顺序做。
4. 只有 01 检查发现 start-dfs.sh 没有路径时，才运行 02 修复脚本。

【如何运行 02 修复脚本】
打开终端，执行：
cd ~/Desktop/BigData_Lesson3_Student
bash 02_fix_hadoop_path.sh

运行结束后，关闭当前终端，重新打开一个新终端，然后重新执行：
command -v start-dfs.sh

如果显示：
/usr/local/hadoop/sbin/start-dfs.sh
说明修复成功，可以进入 03_start_hdfs.txt。

【主线】
01_check_env.txt          环境检查
02_fix_hadoop_path.sh     仅PATH有问题时运行
03_start_hdfs.txt         启动并验收HDFS
04_hdfs_file_loop.txt     本地→HDFS→本地
05_observe_block.txt      看Block和9870
06_stop_hdfs.txt          正确停止
07_optional_B_task.txt    做完必做后再做
