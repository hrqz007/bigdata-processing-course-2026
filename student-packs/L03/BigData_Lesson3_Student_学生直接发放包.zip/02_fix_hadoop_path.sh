#!/usr/bin/env bash
# 只在 command -v start-dfs.sh 没有输出时运行。
# 作用：备份 ~/.bashrc，清理已知危险/重复的 Hadoop 配置，再写入一份干净配置。
# 不会格式化 HDFS，不会安装软件，不会修改 Hadoop 数据。

set -u

HADOOP_DIR="/usr/local/hadoop"
BASHRC="$HOME/.bashrc"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$HOME/.bashrc_before_bigdata_${STAMP}"

if [ ! -x "$HADOOP_DIR/bin/hadoop" ]; then
  echo "[停止] 没找到 $HADOOP_DIR/bin/hadoop。请举手找老师，不要继续。"
  exit 1
fi

cp "$BASHRC" "$BACKUP"
echo "[1/4] 已备份 .bashrc -> $BACKUP"

# 删除已知会造成递归的 source ~/.bashrc，以及曾经误粘贴进去的“按ESC”提示。
sed -i -E '/^[[:space:]]*source[[:space:]]+(~\/\.bashrc|\/home\/[^/]+\/\.bashrc)[[:space:]]*$/d' "$BASHRC"
sed -i -E '/^[[:space:]]*\.[[:space:]]+(~\/\.bashrc|\/home\/[^/]+\/\.bashrc)[[:space:]]*$/d' "$BASHRC"
sed -i '/按ESC/d' "$BASHRC"

echo "[2/4] 已清理已知危险递归行。"

# 删除旧的 Hadoop 环境变量行，避免重复叠加。
sed -i '/HADOOP_HOME/d' "$BASHRC"
sed -i -E '/^[[:space:]]*export[[:space:]]+PATH=.*\/usr\/local\/hadoop\/(bin|sbin)/d' "$BASHRC"

cat >> "$BASHRC" <<'BLOCK'

# ===== Hadoop 3.3.5 for Big Data course =====
export HADOOP_HOME=/usr/local/hadoop
export PATH="$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH"
# ===== Hadoop end =====
BLOCK

echo "[3/4] 已写入唯一一份 Hadoop 环境变量。"

# 这里只在脚本自身中临时验证路径，不 source ~/.bashrc，避免旧终端被历史配置污染。
export HADOOP_HOME=/usr/local/hadoop
export PATH="$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH"

echo "[4/4] 临时验证："
command -v hadoop || true
command -v start-dfs.sh || true
command -v stop-dfs.sh || true

echo
echo "=== 修复完成 ==="
echo "请关闭当前终端窗口，再重新打开一个新终端。"
echo "新终端中重新运行：command -v start-dfs.sh"
echo "如果能看到 /usr/local/hadoop/sbin/start-dfs.sh，就进入下一阶段。"
