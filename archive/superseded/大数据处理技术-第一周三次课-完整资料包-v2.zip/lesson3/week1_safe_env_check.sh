#!/usr/bin/env bash
# 只读环境自检：不会安装软件、不会修改配置、不会格式化HDFS。
set +e

echo '===== 1. USER / OS ====='
whoami
pwd
cat /etc/os-release | grep -E '^(NAME|VERSION|VERSION_ID)=' | head

echo '===== 2. MEMORY / DISK / IP ====='
free -h
df -h /
ip -br addr 2>/dev/null || ip addr

echo '===== 3. JAVA ====='
command -v java
java -version 2>&1 | head -n 3
echo "JAVA_HOME=$JAVA_HOME"

echo '===== 4. HADOOP / HDFS ====='
command -v hadoop
hadoop version 2>/dev/null | head -n 4
command -v hdfs
hdfs version 2>/dev/null | head -n 4
command -v start-dfs.sh
command -v jps

echo '===== 5. HDFS CONFIG ====='
if command -v hdfs >/dev/null 2>&1; then
  echo -n 'fs.defaultFS = '; hdfs getconf -confKey fs.defaultFS 2>/dev/null
  echo -n 'dfs.blocksize = '; hdfs getconf -confKey dfs.blocksize 2>/dev/null
  echo -n 'dfs.replication = '; hdfs getconf -confKey dfs.replication 2>/dev/null
  echo -n 'http-address = '; hdfs getconf -confKey dfs.namenode.http-address 2>/dev/null
fi

echo '===== 6. JAVA PROCESSES ====='
jps 2>/dev/null || true

echo '===== END ====='
