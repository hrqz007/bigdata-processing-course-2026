#!/usr/bin/env bash
set +e
printf '
===== 1. SYSTEM =====
'
whoami
pwd
hostname
cat /etc/os-release | sed -n '1,8p'
free -h
df -h /
ip -br addr 2>/dev/null || true

printf '
===== 2. JAVA =====
'
command -v java || true
java -version 2>&1 || true
printf 'JAVA_HOME=%s
' "${JAVA_HOME:-<empty>}"

printf '
===== 3. HADOOP =====
'
command -v hadoop || true
command -v hdfs || true
command -v start-dfs.sh || true
hadoop version 2>&1 | head -10 || true
printf 'HADOOP_HOME=%s
' "${HADOOP_HOME:-<empty>}"

printf '
===== 4. HDFS CONFIG =====
'
hdfs getconf -confKey fs.defaultFS 2>&1 || true
hdfs getconf -confKey dfs.replication 2>&1 || true
hdfs getconf -confKey dfs.blocksize 2>&1 || true

printf '
===== 5. JAVA PROCESSES =====
'
jps 2>&1 || true

printf '
===== 6. HDFS REPORT (if running) =====
'
hdfs dfsadmin -report 2>&1 | head -60 || true

printf '
===== DONE =====
'
printf 'This script only reads status. It does NOT format, install, start or stop HDFS.
'
