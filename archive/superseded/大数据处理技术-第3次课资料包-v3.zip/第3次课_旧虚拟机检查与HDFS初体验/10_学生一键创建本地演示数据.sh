#!/usr/bin/env bash
set -e
mkdir -p "$HOME/bigdata_course/week1"
cat > "$HOME/bigdata_course/week1/hello_hdfs.txt" <<'EOF'
hello hdfs
big data processing
hadoop spark flink
EOF
cat > "$HOME/bigdata_course/week1/week1_demo_logs.csv" <<'EOF'
user_id,item_id,behavior,event_time
u001,i101,pv,2026-09-03 09:00:01
u002,i102,pv,2026-09-03 09:00:03
u001,i101,cart,2026-09-03 09:00:10
u003,i103,pv,2026-09-03 09:00:12
u002,i102,buy,2026-09-03 09:00:20
u004,i101,pv,2026-09-03 09:00:25
EOF
printf 'Created:
'
ls -lh "$HOME/bigdata_course/week1"
