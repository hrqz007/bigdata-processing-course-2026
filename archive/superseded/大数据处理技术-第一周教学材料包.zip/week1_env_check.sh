#!/usr/bin/env bash
# 大数据处理技术第一周：只读环境自检脚本
# 作用：检查Ubuntu、资源、Java、Hadoop/HDFS、关键配置和当前Java进程。
# 安全性：本脚本不会安装软件、不会修改配置、不会格式化NameNode、不会启动/停止服务。

set -u

line() { printf '%*s\n' 72 '' | tr ' ' '='; }
section() { echo; line; echo "[$1]"; line; }
ok() { echo "[OK] $1"; }
warn() { echo "[WARN] $1"; }
info() { echo "[INFO] $1"; }

section "1. 当前用户与系统"
echo "USER: ${USER:-unknown}"
echo "HOME: ${HOME:-unknown}"
echo "PWD : $(pwd)"
if [ -r /etc/os-release ]; then
  grep -E '^(NAME|VERSION|VERSION_ID|PRETTY_NAME)=' /etc/os-release || true
else
  warn "/etc/os-release 不可读"
fi
uname -a || true

section "2. 内存、磁盘、IP"
free -h || true
df -h / || true
if command -v ip >/dev/null 2>&1; then
  ip -br addr || true
else
  warn "未找到 ip 命令"
fi

section "3. Java"
if command -v java >/dev/null 2>&1; then
  ok "找到 java: $(command -v java)"
  java -version 2>&1 | head -n 5
  JAVA_REAL=$(readlink -f "$(command -v java)" 2>/dev/null || true)
  [ -n "${JAVA_REAL:-}" ] && info "java real path: $JAVA_REAL"
  info "JAVA_HOME=${JAVA_HOME:-<未设置>}"
else
  warn "没有找到 java 命令"
fi

section "4. Hadoop / HDFS 命令"
if command -v hadoop >/dev/null 2>&1; then
  ok "找到 hadoop: $(command -v hadoop)"
  hadoop version 2>&1 | head -n 12
else
  warn "没有找到 hadoop 命令。不要在课堂上自行安装，先由教师统一确认母盘。"
fi

if command -v hdfs >/dev/null 2>&1; then
  ok "找到 hdfs: $(command -v hdfs)"
  hdfs version 2>&1 | head -n 8 || true
else
  warn "没有找到 hdfs 命令"
fi

info "HADOOP_HOME=${HADOOP_HOME:-<未设置>}"
info "HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-<未设置>}"

section "5. HDFS关键配置（仅在hdfs命令存在时读取）"
if command -v hdfs >/dev/null 2>&1; then
  for key in fs.defaultFS dfs.blocksize dfs.replication dfs.namenode.http-address; do
    printf '%-32s : ' "$key"
    hdfs getconf -confKey "$key" 2>/dev/null || echo "<读取失败或未显式配置>"
  done
else
  warn "跳过：hdfs命令不存在"
fi

section "6. 当前Java进程"
if command -v jps >/dev/null 2>&1; then
  jps || true
else
  warn "未找到 jps。通常它随JDK提供。"
fi

section "7. 当前HDFS状态（只读）"
if command -v hdfs >/dev/null 2>&1; then
  if hdfs dfsadmin -report >/tmp/week1_hdfs_report.$$ 2>/tmp/week1_hdfs_report_err.$$; then
    ok "NameNode可响应 dfsadmin -report"
    grep -E '^(Live datanodes|Dead datanodes|Configured Capacity|Present Capacity)' /tmp/week1_hdfs_report.$$ || true
  else
    warn "dfsadmin -report 失败。可能HDFS尚未启动，或配置/网络有问题。"
    head -n 8 /tmp/week1_hdfs_report_err.$$ || true
  fi
  rm -f /tmp/week1_hdfs_report.$$ /tmp/week1_hdfs_report_err.$$
else
  warn "跳过：hdfs命令不存在"
fi

section "8. 自检结论提示"
if command -v java >/dev/null 2>&1 && command -v hadoop >/dev/null 2>&1 && command -v hdfs >/dev/null 2>&1; then
  ok "Java、Hadoop、HDFS命令均存在。下一步可按教师要求执行 start-dfs.sh。"
else
  warn "基础命令不完整。请把本脚本完整输出发给教师，不要自行升级或重装。"
fi

echo
line
echo "自检完成。"
line
