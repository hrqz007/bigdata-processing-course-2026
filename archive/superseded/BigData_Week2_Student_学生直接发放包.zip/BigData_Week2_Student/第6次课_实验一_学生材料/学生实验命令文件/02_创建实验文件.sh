#!/usr/bin/env bash
set -e

WORK="$HOME/bigdata_course/week2_exp1"
mkdir -p "$WORK"

BLOCK_BYTES=$(hdfs getconf -confKey dfs.blocksize)
REPL=$(hdfs getconf -confKey dfs.replication)

cat > "$WORK/small_orders.csv" <<'EOF'
order_id,user_id,amount
E001,U001,19.9
E002,U002,88.0
E003,U003,299.0
E004,U001,35.5
E005,U004,1299.0
EOF

DEMO_BYTES=$((BLOCK_BYTES + 1048576))
truncate -s "$DEMO_BYTES" "$WORK/block_demo.bin"

echo "=== 实验参数 ==="
echo "BlockSize(bytes) = $BLOCK_BYTES"
echo "Replication     = $REPL"
echo "DemoSize(bytes)= $DEMO_BYTES  (BlockSize + 1 MiB)"
echo
echo "=== 本地文件 ==="
ls -lh "$WORK/small_orders.csv" "$WORK/block_demo.bin"
